<?php

/*
 * This file is part of Slim HTTP Basic Authentication middleware
 *
 * Copyright (c) 2013-2015 Mika Tuupola
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Project home:
 *   https://github.com/tuupola/slim-basic-auth
 *
 */

namespace Slim\Middleware\HttpBasicAuthentication;

class TokenAuthenticator implements AuthenticatorInterface
{
    private $options;


    public static $session;
    public function __construct(array $options = array(), $container = array(), $session_class = UserSession::class)
    {

        /* Default options. */
        $this->options = array(
            "table" => "users",
            "token" => "token"
        );

        $this->container = $container;
        $this->session_class = $session_class;

        if ($options) {
            $this->options = array_merge($this->options, $options);
        }
    }

    public function __invoke(array $arguments)
    {
        $token = $arguments["token"];
        $driver = $this->options["pdo"]->getAttribute(\PDO::ATTR_DRIVER_NAME);

        $sql = $this->sql();

        $instance = $this;
        $statement = $this->options["pdo"]->prepare($sql);
        $statement->execute(array($token));

        if ($user = $statement->fetch(\PDO::FETCH_ASSOC)) {
//            return password_verify($password, $user[$this->options["hash"]]);
            $this->container["session"]  = $user;
            TokenAuthenticator::$session = new UserSession($user);

            /*if(is_callable($instance->session_class)){
                $this->container->log->info("Callable");
                TokenAuthenticator::$session = call_user_func($instance->session_class, $user);
            }
            else{

                $this->container->log->info("Not Callable");
            }*/
            return true;
        }

        return false;
    }

    public function sql()
    {
        $driver = $this->options["pdo"]->getAttribute(\PDO::ATTR_DRIVER_NAME);

        /* Workaround to test without sqlsrv with Travis */
        if (defined("__PHPUNIT_ATTR_DRIVER_NAME__")) {
            $driver = __PHPUNIT_ATTR_DRIVER_NAME__;
        }

        if ("sqlsrv" === $driver) {
            $sql =
                "SELECT TOP 1 *
                 FROM {$this->options['table']}
                 WHERE {$this->options['token']} = ?";
        } else {
            $sql =
                "SELECT *
                 FROM {$this->options['table']}
                 WHERE {$this->options['token']} = ?
                 LIMIT 1";
        }

        return preg_replace("!\s+!", " ", $sql);
    }
}
