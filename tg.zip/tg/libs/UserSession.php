<?php
/**
 * Created by PhpStorm.
 * User: Masoud
 * Date: 5/29/2016
 * Time: 12:48 AM
 */

namespace Slim\Middleware\HttpBasicAuthentication;


class UserSession
{

    public function __construct($session = array()){
        $this->id = $session["id"];
        $this->name = $session["user"];
        $this->token = $session["token"];
        $this->role = $session["role"];
        $this->gem = $session["gem"];
        $this->up_line = $session["up_line"];
        $this->join_coin = $session["join_coin"];
        $this->view_coin = $session["view_coin"];
        $this->status = $session["status"];
        $this->version= $session["version"];
        $this->market= $session["market"];
        if(isset($session["last_coin_date"])){
          $this->lastCoinDate = $session["last_coin_date"];
        }
    }

    public function getJoinCoins(){
        return $this->join_coin;
    }
    public function getViewCoins(){
        return $this->view_coin;
    }

    public function isAdmin(){return $this->role == 3;}
    public function isAdvertiser(){return $this->role == 2 || $this->role == 3;}
}
