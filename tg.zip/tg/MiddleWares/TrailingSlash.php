<?php
/**
 * Created by PhpStorm.
 * User: Masoud
 * Date: 5/25/2016
 * Time: 1:54 AM
 */

namespace Middleware;

class TrailingSlash
{
    public function __invoke($request, $response, $next)
    {
        $uri = $request->getUri();
        $path = $uri->getPath();
        if ($path != '/' && substr($path, -1) == '/') {
            // permanently redirect paths with a trailing slash
            // to their non-trailing counterpart
            $uri = $uri->withPath(substr($path, 0, -1));
            return $response->withRedirect((string)$uri, 301);
        }

        return $next($request, $response);

    }
}