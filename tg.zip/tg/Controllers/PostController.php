<?php
/**
 * Created by PhpStorm.
 * User: Masoud
 * Date: 5/28/2016
 * Time: 11:48 PM
 */

namespace Controllers;


use Interop\Container\ContainerInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use Slim\Middleware\HttpBasicAuthentication\UserSession;

class PostController extends BaseController
{
    public function temp(Request $request, Response $response, UserSession $session, $args) {
        $response->write("Temp");
        return $response;
    }

    public function get(Request $request, Response $response, UserSession $session, $args)
    {

        $randCount = 5;
//        $secCount = 15;
        $limit = 50;
        if(isset($this->defaults["page_limit"])){
            $limit = $this->defaults["page_limit"];
        }
        try {
            $url = $this->getImageUrl('tg_id');
//            $list2 = $this->db->query("SELECT posts.id, tg_id , message_id ,name,title, $url FROM channels, posts WHERE channels.tg_id = posts.channel_id  AND posts.status = 0  AND   posts.status <> -1   ORDER BY  posts.create_date ASC LIMIT $secCount");
            //$list2 = $this->db->query("SELECT posts.id, tg_id , message_id ,name,title, $url FROM channels, posts WHERE channels.tg_id = posts.channel_id  AND posts.status = 0    ORDER BY  posts.create_date ASC LIMIT $secCount");
            $list2 = $this->db->query("SELECT posts.id, tg_id , message_id ,name,title, posts.desc, $url FROM 
posts
JOIN ( 
    SELECT name,tg_id, title FROM channels GROUP BY tg_id
) 
channel2 ON channel2.tg_id = posts.channel_id
JOIN view_orders ON view_orders.post_id = posts.id
WHERE  posts.status = 0  AND view_orders.status = 0  ".
//AND view_orders.owner_id <> %i
 "AND view_orders.post_id NOT IN (SELECT post_id FROM `views` WHERE user_id = %i) 
 ORDER BY  posts.create_date ASC LIMIT $limit",$session->id,$session->id);

        }catch (\Exception $e){
            return $this->error($response, "خطا در ارتباط با سرور");

        }
        if(count($list2) == 0){
            return $this->error($response, "فعلا پستی برای نمایش وجود ندارد");

        }
        return $this->getResponse($response, $list2);
    }


    /*public function view(Request $request, Response $response, UserSession $session, $args)
    {
        $id = $args["id"];
        if($id ){

            $countView = $this->db->queryFirstField("SELECT count(*)  FROM views WHERE post_id = %i AND user_id = %i",$id, $session->id);

            if($countView){
                return $this->error($response, "شما قبلا این پست را مشاهده کردید");

            }

            try {
                $count = $this->db->queryFirstRow("SELECT total , done , id, owner_id FROM view_orders WHERE post_id = %i AND status = 0",$id);

                if($count ){
                    if($session->id == $count["owner_id"]){
                        return $this->error($response, "پست شما تا کنون ".$count["done"] ." بار در طلاممبر نشان داده شده");
                    }


                    if($count["total"] - $count["done"] == 1){


                        $this->db->insert('views', array(
                            'user_id' => $session->id,
                            'post_id' => $id
                        ));

                        $this->db->update('view_orders', array(
                            'done' => $count["done"]+1,
                            'status' => 1,
                            'done_date' => $this->db->sqleval("NOW()"),
                        ), "id=%i", $count["id"]);
                    }
                    else{

                        $this->db->insert('views', array(
                            'user_id' => $session->id,
                            'post_id' => $id
                        ));

                        $this->db->update('view_orders', array(
                            'done' => $count["done"]+1,
                        ), "id=%i", $count["id"]);

                    }

                    $coin_per_view = $this->defaults["coin_per_view"];
//                  $coin_per_join = $this->defaults["coin_per_join"];
                    $this->updateCoin($session->id, $coin_per_view, $this->TYPE_VIEW);
                    return $this->getResponseWithMessage($response, array(
//                      "viewCoins" => $session->view_coin + $coin_per_view ,
                        "joinCoins" => $session->join_coin + $coin_per_view),"+".$coin_per_view." سکه دریافت شد");
                }

                return $this->error($response, "این پیام حذف شده");
            }catch (\MeekroDBException $e) {
                return $this->error($response, "شما قبلا این پست را مشاهده کردید");
                // return $this->error($response, "Duplicate");
                // return $this->error($response, "Duplicate UserName");

            }
            // return $this->error($response, "Delete");
        }
        return $this->error($response, "شناسه پیام معتبر نیست");
        // return $this->error($response, "Wrong");

    }*/

    public function view(Request $request, Response $response, UserSession $session, $args)
    {
        $id = $args["id"];
        if($id ){

            $countView = $this->db->queryFirstField("SELECT count(*)  FROM views WHERE post_id = %i AND user_id = %i",$id, $session->id);

            if($countView){
                return $this->error($response, "شما قبلا این پست را مشاهده کردید");

            }

            try {
                $count = $this->db->queryFirstRow("SELECT total , done , id, owner_id FROM view_orders WHERE post_id = %i AND status = 0",$id);

                if($count ){
                    if($session->id == $count["owner_id"]){
                        return $this->error($response, "پست شما تا کنون ".$count["done"] ." بار در طلاممبر نشان داده شده");
                    }


                    if($count["total"] - $count["done"] == 1){


                        $this->db->insert('views', array(
                            'user_id' => $session->id,
                            'post_id' => $id
                        ));

                        $this->db->update('view_orders', array(
                            'done' => $count["done"]+1,
                            'status' => 1,
                            'done_date' => $this->db->sqleval("NOW()"),
                        ), "id=%i", $count["id"]);
                    }
                    else{

                        $this->db->insert('views', array(
                            'user_id' => $session->id,
                            'post_id' => $id
                        ));

                        $this->db->update('view_orders', array(
                            'done' => $count["done"]+1,
                        ), "id=%i", $count["id"]);

                    }

                    $coin_per_view = $this->defaults["coin_per_view"];
//                  $coin_per_join = $this->defaults["coin_per_join"];
                    $this->updateViewCoin($session->id, $coin_per_view, $this->TYPE_VIEW);
                    return $this->getResponseWithMessage($response, array(
//                      "viewCoins" => $session->view_coin + $coin_per_view ,
                        "joinCoins" => $session->join_coin + $coin_per_view),"+".$coin_per_view." سکه دریافت شد");
                }

                return $this->error($response, "این پیام حذف شده");
            }catch (\MeekroDBException $e) {
//                return $this->error($response, "شما قبلا این پست را مشاهده کردید");
                 return $this->error($response, $e->getMessage());
                // return $this->error($response, "Duplicate UserName");

            }
            // return $this->error($response, "Delete");
        }
        return $this->error($response, "شناسه پیام معتبر نیست");
        // return $this->error($response, "Wrong");

    }


    public function add(Request $request, Response $response, UserSession $session, $args) {
//        $tg_url = $args["channel_id"]."/".$args["message_id"];
        // $url = "localhost:8000/app/index.html#/add/".$tg_url;
        // $browser = "\"C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe\" ".$url;

        $channel = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE tg_id = %i AND status <> -1",$args["channel_id"]);
        if(!$channel){
            return $this->error($response, "این کانال قبلا ثبت نشده یا مسدود است");

        }
        $price = $this->db->queryFirstField("SELECT price FROM CoinsPrice WHERE type = 4 AND count = %i",$args["total"]);
        if($price < 1){
            $price = 999999;
        }
        // $price = $this->defaults["coin_per_view"] * $args["count"];
        if($price> $session->join_coin)
        {
            return $this->error($response, "اعتبار کافی نیست");
        }

        // shell_exec($browser);
        $body = $request->getParsedBody();
        if(isset($body["text"])){
            $text = $body["text"];
            /*if($this->checkWord($text)){
              return $this->error($response, "کلمات نامناسب در متن پست قرار دارد");
            }*/
        }
        else {
            $text = "";
        }
        $args2 = $args;
        try {

            unset($args["total"]);
            $args["desc"] = substr($text,0,strlen($text) > 300 ? 300:strlen($text));
//            return $this->error($response, $args["desc"]);

            $this->db->insert('posts', $args);
            $post_id = $this->db->insertId();

        } catch (\MeekroDBException $e) {
            $post_id = $this->db->queryFirstField("SELECT id FROM posts WHERE channel_id = %i AND message_id = %i",$args["channel_id"],$args["message_id"]);

            $count = $this->db->queryFirstField("SELECT COUNT(*) FROM view_orders WHERE post_id = %i AND status = 0",$post_id);
//            return $this->error($response, "post: ".$post_id." ,count: ".$count." ,".$e->getMessage());

            if($count){
                return $this->error($response, "یک سفارش جاری برای این پست وجود دارد");

            }
//            return $this->error($response, "این پست قبلا سفارش داده شده");
            // return $this->error($response, "Duplicate UserName");

        }
        unset($args2["channel_id"]);
        unset($args2["message_id"]);
        $args2["owner_id"]=$session->id;
        $args2["post_id"]=$post_id;
        $this->db->insert('view_orders', $args2);
        $this->updateShitil($session->id, - $price,$this->TYPE_VIEW);
        return $this->getResponse($response, array("joinCoins" => $session->join_coin - $price ));

    }

    private function checkWord($text){
        $badwords = array();
        array_push($badwords,
            'anal',
            'anus',
            'ass',
            'boob',
            'cock',
            'cum',
            'cunt',
            'dick',
            'dildo',
            'dyke',
            'fag',
            'faggot',
            'fuck',
            'fuk',
            'handjob',
            'jizz',
            'kunt',
            'muff',
            'nigger',
            'penis',
            'poop',
            'pussy',
            'queer',
            'rape',
            'semen',
            'sex',
            'slut',
            'titties',
            'vulva',
            'wank'
        );
        array_push($badwords,


            'کون',
            'حشر',
            'حشری',
            'گائیدن',
            'گایش',
            'کردن کون',
            'سکس',
            'سکسی',
            'کیر',
            'تف سر کیر',
            'پستون',
            'پستان',
            'لاپا',
            'ساک زدن',
            'کون گنده',
            'جق زدن',
            'جق بزنیم',
            'جق',
            'سک30',
            'شهوتسرا',
            'سوپرایرانی',
            'ساك زدن',
            'بکنمت',
            'سكس',
            'گله پونه',
            'گاییدن',
            'گاييدن',
            'سوپر',
            'گی ',
            'صکصی',
            'صکصي',
            'ســ.ــکــ.ــس',
            'حشــ.ــری',
            'جلق',
            'جرق',
            'جنده',
            'فاحشه'
        );
        foreach ($badwords as $key => $value) {
            if(strpos($text, $value) !== false){
                return true;
            }
        }
        return false;
    }


    public function remove(Request $request, Response $response, UserSession $session, $args)
    {
        $this->db->update('posts', array(
            'status' => -1
        ), "id=%i ", $args["id"]);
        if ($this->db->affectedRows()) {
            return $this->getResponse($response, true);
        } else {
            return $this->error($response, "خطا");
        }
    }


    public function history(Request $request, Response $response, $session, $args) {
        $url = $this->getImageUrl('tg_id');

        $history = $this->db->query("SELECT  view_orders.status,name, view_orders.total, view_orders.done, message_id as `left`, 2 AS type, view_orders.create_date AS date
FROM 
posts
JOIN ( 
    SELECT name,tg_id FROM channels GROUP BY tg_id
) 
channel2 ON channel2.tg_id = posts.channel_id
JOIN view_orders ON view_orders.post_id = posts.id
WHERE   view_orders.owner_id = %i
ORDER BY view_orders.create_date DESC",$session->id );
        if (count($history) == 0) {
            return $this->error($response, "شما هیچ سفارش بازدیدی نداده اید");
        }
        return $this->getResponse($response,$history);
    }


}
