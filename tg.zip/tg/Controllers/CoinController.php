<?php
/**
 * Created by PhpStorm.
 * User: Masoud
 * Date: 5/28/2016
 * Time: 11:48 PM
 */

namespace Controllers;


use Interop\Container\ContainerInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use Slim\Middleware\HttpBasicAuthentication\UserSession;
use DateTime;
class CoinController extends BaseController
{


    public function check2($product,$tokenid, $market = "bazaar"){
        /*if(empty($_REQUEST['package']) || empty($_REQUEST['product']) || empty($_REQUEST['tokenid'])){
            echo "error";
            return;
        }

        $product = $_REQUEST['product'];
        $tokenid = $_REQUEST['tokenid'];*/
//b3QSnx0BEqXA8K4D9SDwvOhSrg5pN5
        $package = "ir.tala.member";
        if($market == "bazaar") {
//            $refcode = 'yBHttX7irl4jOzKwYkUqL7PqgiMZMF';
            $refcode = '3Eh32BsNbhKoSHBKsfMybt8UhuznsB';
            $code = 'MlrzLQBNmZpyxNqWTCmVNScytpnz8K';
//            $accesscode = '0BaXATOohm8Eb1rUJS6qZVYdLEEUkH';
            $accesscode = 'B5HwEkYow899W43MYVMt0ci1XoBYms';
            $red = "https://nivad.io/panel/app/ir.appmy.cafemember2/service/billing/client/code/";

//            $client_id = "9fvWQRHW8rJsjA1kdnXCrTfhscYt2JmEvqwGnrjR";
            $client_id = "NWAhlWjUSDf2lDqXnfwLtP4EGisfpmbxe5cEOdc9";
//            $client_secret = "UItjftycUwTAFOZrav8Y8tLdAH9IzWyK2tfvioXcLDMdwSYhXBKyGRY7y8go";
            $client_secret = "RDphl5gPir9NiLp7hZBPOvXVwRbMN4cAU4wFaF2EezHrf7N7zLcV8iECnSlO";
            $url = 'http://pardakht.cafebazaar.ir/auth/token/';
            $data = array('grant_type' => 'refresh_token', 'client_id' => $client_id, 'client_secret' => $client_secret, 'refresh_token' => $refcode);

# Create a connection
            $ch = curl_init($url);
# Form data string
            $postString = http_build_query($data, '', '&');

# Setting our options
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

# Get the response
            $response = curl_exec($ch);
            curl_close($ch);

            $jsonResponse = json_decode($response, true);

            $access_token = $jsonResponse['access_token'];

            $result = file_get_contents("https://pardakht.cafebazaar.ir/api/validate/$package/inapp/$product/purchases/$tokenid/?access_token=$access_token");
//        echo $result;
        }
        else if($market == "myket"){
try{
            $url = "https://api.myket.ir/IapService.svc/getpurchases?";
            $data = array(
                "packagename"=>$package,
                "productId"=>$product,
                "token"=>$tokenid,
            );
            $postString = http_build_query($data, '', '&');
            //$ch = curl_init($url.$postString);
            //curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

//            return $postString;
# Get the response
            //$response = curl_exec($ch);
//            return $response;
            //curl_close($ch);

//            $result = json_decode($response, true);
//            $result = file_get_contents($url."?packagename=$package&productId=$product&token=$tokenid");
            $result = file_get_contents($url.$postString);
            }catch(\Exception $e){
                return false;
            }
        }

        else if($market == "iranapps") {
//            $refcode = 'yBHttX7irl4jOzKwYkUqL7PqgiMZMF';
            $refcode = 'WL6-qwlE6kUbHKstDj-bxEaLsr24URoALN_L6Sbn';
//            $accesscode = '1dUGfRBFR80U2z2KH8V1H-gr8vd18LGFxRRZwSJE';

//        $code = "tXljmsK529r5K9a4XfZiSoSxGrEqLhS-Tvw26mVH";
            $client_id = "oYuKErmMqjB_1FKs8lJFSchGExEXtuzr";
            $client_secret = "Vy0IZeW5loqJ-1fYFM6Nwcm4ZWD3_rd4";
            $url = 'http://api.iranapps.ir/v2/auth/token/';
            $data = array('grant_type' => 'refresh_token', 'client_id' => $client_id, 'client_secret' => $client_secret, 'refresh_token' => $refcode);

# Create a connection
            $ch = curl_init($url);
# Form data string
            $postString = http_build_query($data, '', '&');

# Setting our options
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

# Get the response
            $response = curl_exec($ch);
            curl_close($ch);

            $jsonResponse = json_decode($response, true);
//echo "TOKEN Is: ".$tokenid."\n";
//echo "Auth: ".$jsonResponse ;
            $access_token = $jsonResponse['access_token'];

            $result = file_get_contents("http://api.iranapps.ir/v2/applications/$package/purchases/products/$product/tokens/$tokenid?access_token=$access_token");
            //  echo "Res2: ".$result;
        }
        else{
            return false;
        }

        $res = json_decode($result);
//        return $res;
        return $res && isset($res->purchaseState ) && $res->purchaseState== 0;

    }

    public function buyCoin2(Request $request, Response $response, UserSession $session, $args)
    {
		
	  /*if(isset($session->market)&&$session->market != ""){
           $def = $this->db->queryFirstRow("SELECT * FROM versions WHERE market = %s",$session->market);
              if($session->version < $def["code"]){

                  return $this->error($response,"برای خرید سکه باید از آخرین نسخه کافه ممبر استفاده نمایید");
              }

          }else{

                  return $this->error($response,"برای خرید سکه باید از آخرین نسخه کافه ممبر استفاده نمایید");
          }*/
		
        $coin = $this->db->queryFirstRow("SELECT * FROM CoinsPrice WHERE sku = %s",$args["id"]);

        if(!isset($args["market"])){
            $args["market"] = "bazaar";
        }
        switch ($coin["type"]) {
            case 2:
                $coinType = "view_coin";
                $cointTypeResponse = "viewCoins";
                $lastCoin = $session->getViewCoins();
                break;
            case 1:
                $cointTypeResponse = "joinCoins";
                $coinType = "join_coin";
                $lastCoin = $session->getJoinCoins();
                break;

            default:
                $coinType = "";
                break;
        }
        $newCoin = $lastCoin + $coin["count"];
        if($coinType == ""){
            return $this->error($response, "نوع سکه معتبر نیست");

        }
        $body = $request->getParsedBody();
        if($body && isset($body["orderId"])){
            $body["user_id"] = $session->id;
            $body["market"] = $args["market"];
            //echo $body["market"];
            unset($body["autoRenewing"]);
            $this->db->insert("transactions",$body);
//            $res = $this->check($body["productId"],$body["orderId"]);
//            return $this->getResponse($response, $res);

            $id = $this->db->insertId();
            if($args["market"] == "iranapps"){
                $token = $body["purchaseToken"];
            }
            else{
                $token = $body["orderId"];
            }
//            return $this->getResponse($response,$this->check2($body["productId"] ,$token , $args["market"]));


	//    $check_token = $this->db->queryFirstField("SELECT COUNT(*) FROM coins_log WHERE token = '$token'");
            $check_token = $this->db->queryFirstRow("SELECT user_id,token FROM coins_log WHERE token = '$token' AND token IN (SELECT orderId FROM transactions WHERE user_id = $session->id)");

	    if ($check_token > 0) {
                 // return $this->getResponse($response,array("message"=>"این خرید قبلا استفاده شده و سکه‌های آن را نیز دریافت نموده‌اید جهت خرید سکه لطفاً دوباره اقدام نمایید"));
                    return $this->error($response,"این خرید قبلا استفاده شده و سکه‌های آن را نیز دریافت نموده‌اید جهت خرید سکه لطفاً دوباره اقدام نمایید");
	    }


            if($this->check2($body["productId"] ,$token , $args["market"])){

                $this->updateCoin($session->id,$coin["count"],$this->TYPE_BUY,$token);

                return $this->getResponse($response, array("$cointTypeResponse" => $newCoin, "db"=>$this->db->affectedRows()));

            }else{
                $this->db->update("transactions",array("fake"=>1),"id = %i",$id);

                return $this->error($response, "پرداخت شما از طرف مارکت تایید نشده است");

            }


        }
        else{
	      return $this->error($response, "جهت خرید و دریافت سکه باید کافه ممبر را به نسخه 5 ارتقا دهید");
        //    $this->updateCoin($session->id,$coin["count"],$this->TYPE_BUY);

       //     return $this->getResponse($response, array("$cointTypeResponse" => $newCoin, "db"=>$this->db->affectedRows()));
        }
        return $this->error($response, "عملیات نا معتبر است");
    }


    public function get(Request $request, Response $response, UserSession $session, $args)
    {

      // return $this->getResponse($response, array("joinCoins" => $session->getJoinCoins(), "viewCoins" => $session->getViewCoins()));
        // if($session->lastCoinDate != null || )
        // $this->db->update('users', array(
        //     'join_coin'=>$session->getJoinCoins()+$this->defaults["coin_per_day"],
        //     'last_coin_date'=>new DateTime()
        // ),"DATE(last_coin_date) <> CURDATE() AND id=%i",$session->id);
        $coinPrice = 1;
        if(isset($this->defaults["coinPrice"])){
            $coinPrice = $this->defaults["coinPrice"];
        }
        $data = $this->getLastMessage();
        $now = new DateTime();
        $this->db->query("UPDATE users SET join_coin = %i , last_coin_date = NOW() WHERE DATE(last_coin_date) <> CURDATE() AND id=%i",$session->getJoinCoins()+$this->defaults["coin_per_day"], $session->id);
        if($this->db->affectedRows()){
          $data["joinCoins"] = $session->getJoinCoins()+$this->defaults["coin_per_day"];
          $data["viewCoins"] = $session->getViewCoins()+$this->defaults["coin_per_day"];
          $data["coinPrice"] = $coinPrice;
        }
        else{
            $data["joinCoins"] = $session->getJoinCoins();
            $data["viewCoins"] = $session->getJoinCoins();
            $data["coinPrice"] = $coinPrice;

        }
        return $this->getResponse($response, $data);

    }

    public function getLastMessage(){
        return $this->db->queryFirstRow("SELECT id AS messageID, message FROM messages ORDER BY id DESC LIMIT 1");
    }

    public function getCoinsPrice(Request $request, Response $response, UserSession $session, $args)
    {
      return $this->getResponse($response, array("joinCoins" => $this->db->query("SELECT * FROM CoinsPrice WHERE type = 1 AND sku <> 'm10'"), "viewCoins" => $this->db->query("SELECT * FROM CoinsPrice WHERE type = 2 ")));

        // return $this->getResponse($response, $this->db->query("SELECT * FROM CoinsPrice WHERE type = 1 OR type = 2"));
    }
    public function getCharges(Request $request, Response $response, UserSession $session, $args)
    {
        /*$charges = $this->db->query("SELECT charge_type.id, type, info, coins_price FROM charge
        JOIN charge_type ON charge_type.id = charge.type_id WHERE used = 0 GROUP BY charge_type.id");*/

        $charges = $this->db->query("SELECT charge_type.id, type, info, coins_price FROM  charge_type ");

        $now = new DateTime();
        $start = new DateTime();
        $end = new DateTime();
        $s = $this->defaults["charge_start"];
        $e = $this->defaults["charge_end"];
        $start->setTime($s,0,0);
        $end->setTime($e,0,0);
        $message = "";
        if($now < $start || $now > $end){
            $message =            "زمان دریافت شارژ بین ساعت ".$s." تا ".$e." می باشد.";

        }
        if(count($charges) == 0){
            return $this->error($response, "در حال حاضر هیچ کارت شارژی موجود نیست");

        }
      return $this->getResponseWithMessage($response, $charges, $message);

        // return $this->getResponse($response, $this->db->query("SELECT * FROM CoinsPrice WHERE type = 1 OR type = 2"));
    }
    public function buyCharge(Request $request, Response $response, UserSession $session, $args)
    {
        $now = new DateTime();
        $start = new DateTime();
        $end = new DateTime();
        $s = $this->defaults["charge_start"];
        $e = $this->defaults["charge_end"];
        $start->setTime($s,0,0);
        $end->setTime($e,59,59);
        if($now < $start || $now > $end){
            $message =            "زمان دریافت شارژ بین ساعت ".$s." تا ".$e." می باشد.";
            return $this->error($response, $message);


        }
        $type = $args["id"];
        try {
            $this->db->startTransaction();
            $charge = $this->db->queryFirstRow("SELECT charge.id,  coins_price, code FROM charge
        JOIN charge_type ON charge_type.id = charge.type_id WHERE used = 0 AND type_id = %s ", $type);
            if ($charge) {
                if ($charge["coins_price"] > $session->join_coin) {
                    return $this->getResponse($response, "موجودی شما کافی نیست!");

                }
                $this->db->update("charge", array(
                    "user_id" => $session->id,
                    "use_date" => $this->db->sqleval("NOW()"),
                    "used" => 1,
                ), "id = %i", $charge["id"]);
                $newCoin = $session->join_coin - $charge["coins_price"];
                $this->updateShitil($session->id, -$charge["coins_price"],$this->TYPE_SHITIL);
                $this->db->commit();
//                return $this->getResponse($response, array("joinCoins" => $newCoin));

                return $this->getResponseWithMessage($response, array("joinCoins" => $newCoin), "کد شارژ: ".$charge["code"]);

            }
            else{
                $this->db->commit();
                return $this->getResponseWithMessage($response, array("joinCoins" => $session->join_coin),"متاسفانه موجودی این نوع شارژ تمام شده!");

//                return $this->getResponse($response, );

            }
        }catch (\MeekroDBException $e){
            $this->db->rollback();
            return $this->getResponse($response, "متاسفانه خطایی در سرور رخ داد!");

        }

        // return $this->getResponse($response, $this->db->query("SELECT * FROM CoinsPrice WHERE type = 1 OR type = 2"));
    }
    public function getDefaultCoins(Request $request, Response $response, UserSession $session, $args)
    {
      return $this->getResponse($response, array("joinCoins" => $this->db->query("SELECT count,price,info FROM CoinsPrice WHERE type = 3"), "viewCoins" => $this->db->query("SELECT count,price,info FROM CoinsPrice WHERE type = 4")));

        // return $this->getResponse($response, $this->db->query("SELECT * FROM CoinsPrice WHERE type = 1 OR type = 2"));
    }

    public function setCoinsPrice(Request $request, Response $response, UserSession $session, $args)
    {
      $body = $request->getParsedBody();
        $this->db->insert("CoinsPrice",array(
          "type"=>$body["type"],
          "description"=>$body["description"],
          "price"=>$body["price"],
          "count"=>$body["count"]
        ));

        return $this->getResponse($response, $this->db->insertId());
    }


    public function check($product,$tokenid, $market = "bazaar"){
        /*if(empty($_REQUEST['package']) || empty($_REQUEST['product']) || empty($_REQUEST['tokenid'])){
            echo "error";
            return;
        }

        $product = $_REQUEST['product'];
        $tokenid = $_REQUEST['tokenid'];*/
//b3QSnx0BEqXA8K4D9SDwvOhSrg5pN5
        $package = "ir.appmy.cafemember2";
        if($market == "bazaar") {
//            $refcode = 'yBHttX7irl4jOzKwYkUqL7PqgiMZMF';
            $refcode = '9Fk0crS9JZfcvLkTkzAodqJXliVuYW';
//            $accesscode = '0BaXATOohm8Eb1rUJS6qZVYdLEEUkH';
            $accesscode = 'NIIevVmgkcrUxd21JT6RtkZJYt2nRB';
            $red = "https://nivad.io/panel/app/ir.appmy.cafemember2/service/billing/client/code/";

//            $client_id = "9fvWQRHW8rJsjA1kdnXCrTfhscYt2JmEvqwGnrjR";
            $client_id = "qdjn9aMBuQ6nthV1myYDRvSOrCqakfiFeQIK2IlM";
//            $client_secret = "UItjftycUwTAFOZrav8Y8tLdAH9IzWyK2tfvioXcLDMdwSYhXBKyGRY7y8go";
            $client_secret = "dks72gwV1Jt5l9TkI8YKobAQXuIUQGuQ5MaPHjgknYEBpSheLYEtRrXOtkyt";
            $url = 'http://pardakht.cafebazaar.ir/auth/token/';
            $data = array('grant_type' => 'refresh_token', 'client_id' => $client_id, 'client_secret' => $client_secret, 'refresh_token' => $refcode);

# Create a connection
            $ch = curl_init($url);
# Form data string
            $postString = http_build_query($data, '', '&');

# Setting our options
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

# Get the response
            $response = curl_exec($ch);
            curl_close($ch);

            $jsonResponse = json_decode($response, true);

            $access_token = $jsonResponse['access_token'];

            $result = file_get_contents("https://pardakht.cafebazaar.ir/api/validate/$package/inapp/$product/purchases/$tokenid/?access_token=$access_token");
//        echo $result;
        }
        else if($market == "myket"){
            $url = "https://api.myket.ir/IapService.svc/getpurchases?";
            $data = array(
                "packagename"=>$package,
                "productId"=>$product,
                "token"=>$tokenid,
            );
            $postString = http_build_query($data, '', '&');
            $ch = curl_init($url.$postString);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

# Get the response
            $response = curl_exec($ch);
            curl_close($ch);

            $result = json_decode($response, true);
//            $result = file_get_contents("?packagename=$package&productId=$product&token=$tokenid");
        }

    else if($market == "iranapps") {
//            $refcode = 'yBHttX7irl4jOzKwYkUqL7PqgiMZMF';
        $refcode = 'WL6-qwlE6kUbHKstDj-bxEaLsr24URoALN_L6Sbn';
//            $accesscode = '1dUGfRBFR80U2z2KH8V1H-gr8vd18LGFxRRZwSJE';

//        $code = "tXljmsK529r5K9a4XfZiSoSxGrEqLhS-Tvw26mVH";
        $client_id = "oYuKErmMqjB_1FKs8lJFSchGExEXtuzr";
        $client_secret = "Vy0IZeW5loqJ-1fYFM6Nwcm4ZWD3_rd4";
        $url = 'http://api.iranapps.ir/v2/auth/token/';
        $data = array('grant_type' => 'refresh_token', 'client_id' => $client_id, 'client_secret' => $client_secret, 'refresh_token' => $refcode);

# Create a connection
        $ch = curl_init($url);
# Form data string
        $postString = http_build_query($data, '', '&');

# Setting our options
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

# Get the response
        $response = curl_exec($ch);
        curl_close($ch);

        $jsonResponse = json_decode($response, true);
//echo "TOKEN Is: ".$tokenid."\n";
//echo "Auth: ".$jsonResponse ;
        $access_token = $jsonResponse['access_token'];

        $result = file_get_contents("http://api.iranapps.ir/v2/applications/$package/purchases/products/$product/tokens/$tokenid?access_token=$access_token");
      //  echo "Res2: ".$result;
    }
    else{
        return false;
    }

        $res = json_decode($result);
        return $res && isset($res->purchaseState ) && $res->purchaseState== 0;

    }

    public function buyCoin(Request $request, Response $response, UserSession $session, $args)
    {
        $coin = $this->db->queryFirstRow("SELECT * FROM CoinsPrice WHERE sku = %s",$args["id"]);

        if(!isset($args["market"])){
            $args["market"] = "bazaar";
        }
        switch ($coin["type"]) {
            case 2:
                $coinType = "view_coin";
                $cointTypeResponse = "viewCoins";
                $lastCoin = $session->getViewCoins();
                break;
            case 1:
                $cointTypeResponse = "joinCoins";
                $coinType = "join_coin";
                $lastCoin = $session->getJoinCoins();
                break;

            default:
                $coinType = "";
                break;
        }
        $newCoin = $lastCoin + $coin["count"];
        if($coinType == ""){
            return $this->error($response, "نوع سکه معتبر نیست");

        }
        $body = $request->getParsedBody();
        if($body && isset($body["orderId"])){
            $body["user_id"] = $session->id;
            $body["market"] = $args["market"];
            //echo $body["market"];
            unset($body["autoRenewing"]);
            $this->db->insert("transactions",$body);
//            $res = $this->check($body["productId"],$body["orderId"]);
//            return $this->getResponse($response, $res);

            $id = $this->db->insertId();
if($args["market"] == "iranapps"){
$token = $body["purchaseToken"];
}
else{
$token = $body["orderId"];
}
            if($this->check($body["productId"] ,$token , $args["market"])){

                $this->updateCoin($session->id,$coin["count"],$this->TYPE_BUY);

                return $this->getResponse($response, array("$cointTypeResponse" => $newCoin, "db"=>$this->db->affectedRows()));

            }else{
                $this->db->update("transactions",array("fake"=>1),"id = %i",$id);

                return $this->error($response, "پرداخت شما از طرف مارکت تایید نشده است");

            }


        }
        else{
              return $this->error($response, "جهت خرید و دریافت سکه باید کافه ممبر را به نسخه 5 ارتقا دهید");
          //  $this->updateCoin($session->id,$coin["count"],$this->TYPE_BUY);

          //  return $this->getResponse($response, array("$cointTypeResponse" => $newCoin, "db"=>$this->db->affectedRows()));
        }
        return $this->error($response, "عملیات نا معتبر است");
    }

    public function shitil(Request $request, Response $response, UserSession $session, $args)
    {
        $coin = $args["amount"];
        $market = "bazaar";
        if(isset($args["market"])){
            $market = $args["market"];
        }

       $max = 10;

        $total = $this->db->queryFirstField("SELECT COUNT(*) FROM shitil_log WHERE user_id = %i AND type = 'shitil' AND DATE(date) >= CURRENT_DATE",$session->id);

        if($total > $max){
            return $this->error($response, "تعداد تبلیغاتی که مشاهده کردید بیش از حد مجاز روزانست. متاسفانه سکه ای به شما تعلق نمی گیرد.");
        } 

        $coin = 1;
        $this->updateShitil($session->id,$coin,$this->TYPE_SHITIL);

        return $this->getResponse($response, array("joinCoins" => $session->join_coin + $coin, "joinCoinsPlus" =>  $coin));

    }


    public function adplay(Request $request, Response $response, UserSession $session, $args)
    {
        $coin = $args["amount"];
        $market = "bazaar";
        if(isset($args["market"])){
            $market = $args["market"];
        }

        $max = 20;

        $total = $this->db->queryFirstField("SELECT COUNT(*) FROM shitil_log WHERE user_id = $session->id AND type = 'gift' AND check_day = 0");

        if($total > $max){
            return $this->error($response, "تعداد تبلیغاتی که مشاهده کردید بیش از حد مجاز روزانست. متاسفانه سکه ای به شما تعلق نمی گیرد.");
            
        } 

        $coin = 2;
        $this->updateShitil($session->id,$coin,$this->TYPE_GIFT);

        return $this->getResponse($response, array("joinCoins" => $session->join_coin + $coin, "joinCoinsPlus" =>  $coin));

    }

    public function transfare(Request $request, Response $response, UserSession $session, $args)
    {

  /*    $check_day = $this->db->queryFirstRow("SELECT * FROM transfare WHERE send_coin = $session->name AND check_day = 0");

      if ($check_day > 1 ) {
           return $this->error($response, "انتقال سکه شما برای امروز کامل شده لطفاً روز بعد تلاش نمایید، همچنین روزانه فقط یکبار حق انتقال سکه خواهید داشت");

      } */

	  //return $this->error($response, "انتقال سکه تا اطلاع ثانوی غیر فعال می‌باشد");
      $user = $this->db->queryFirstRow("SELECT * FROM users WHERE user = %s",$args["user"]);
      // $user = ;
      // print_r($user);
      // return $this->error($response, "Done");
      if($session->status != 0){
        return $this->error($response, "اکانت شما مسدود شده است");
      }
      if(count($user) == 0){
        return $this->error($response, "شناسه کاربر معتبر نیست");
      }

      if($user["id"] == $session->id){
        return $this->error($response, "انتقال سکه به خودتان امکان پذیر نیست");
      }
      $amount = $args["amount"];
      
	  if ($amount >= 151){
		  return $this->error($response, "انتقال بیش از 150 سکه قابل قبول نمی‌باشد، همچنین در صورت مشاهده خرید و فروش سکه باعث بلاک شدن خریدار و فروشنده خواهد شد");
               //   return $this->error($response, $session->name);
	  }
	  
      switch ($args["type"]) {
        case 2:
          $coinType = "view_coin";
          $cointTypeResponse = "viewCoins";
          $lastCoin = $session->getViewCoins();
          break;
        case 1:
        $cointTypeResponse = "joinCoins";
          $coinType = "join_coin";
          $lastCoin = $session->getJoinCoins();
          break;

        default:
        $coinType = "";
          break;
      }
      if($lastCoin < $amount){
        return $this->error($response, "موجودی سکه شما کافی نیست");
      }
      if($amount < 0){
        return $this->error($response, "مقدار انتقال باید منفی باشد");
      }
      $newCoin = $lastCoin - $amount;
      $newCoinUser = $user["$coinType"] + $amount;
      if($coinType == ""){
        return $this->error($response, "نوع سکه معتبر نیست");

      }


      $this->db->startTransaction();
        $this->db->update("users",array(
          $coinType=>$newCoin
        ),"id=%i",$session->id);
		
		
        $this->db->update("users",array(
            $coinType=>$newCoinUser
          ),"user=%s",$user["user"]);
          $this->db->commit();
		  
	$this->db->insert("transfare",array(
            'send_coin' => $session->name,
	    'get_coin' => $args["user"],
	    'amount' => $amount
          ),"");		  
		  
        return $this->getResponse($response, array("$cointTypeResponse" => $newCoin ));
    }
    public function payRequest(Request $request, Response $response, UserSession $session, $args)
    {

        $body = $request->getParsedBody();
        $body["user_id"]=$session->id;
      if($session->status != 0){
        return $this->error($response, "اکانت شما مسدود شده است");
      }
      $amount = $body["amount"];

	  if ($amount > $session->getJoinCoins()){
		  return $this->error($response, "موجودی سکه کافی نیست");
               //   return $this->error($response, $session->name);
	  }
	  if ($amount < 5000){
		  return $this->error($response, "حداقل مقدار درخواست 5000 تومان است");
               //   return $this->error($response, $session->name);
	  }



	$this->db->insert("pay_log",$body);

        return $this->getResponseWithMessage($response,array(),"درخواست شما ثبت شد." );
    }

    public function myPays(Request $request, Response $response, UserSession $session, $args)
    {

        $limit ="";
        if(isset($args["from"])){
            $from = $args["from"];
            if(isset($args["to"])){

            }
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT amount, name, date, pay_date, phone, paid, card_number FROM pay_log WHERE user_id = %i ORDER BY date DESC".$limit, $session->id );
        return $this->getResponse($response,$history);
    }

}
