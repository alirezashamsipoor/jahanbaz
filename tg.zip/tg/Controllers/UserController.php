<?php
/**
 * Created by PhpStorm.
 * User: Masoud
 * Date: 5/28/2016
 * Time: 11:48 PM
 */

namespace Controllers;


use Interop\Container\ContainerInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use Slim\Middleware\HttpBasicAuthentication\UserSession;
use DateTime;
class UserController extends BaseController
{
    public function login(Request $request, Response $response, $session, $args) {

        $phone = $args["phone"];
        $token = uniqid($phone.".");

        if(!$this->startsWith($phone,"98")){

            return $this->error($response, "فقط شماره های داخل ایران قابل قبول هستند");
        }
        $existToken = $this->db->queryFirstField("SELECT token FROM users WHERE user = %s",$phone);
        if($existToken){
            return $this->getResponse($response, array("channel_id"=>0,
                "channel_name"=>$this->defaults["channel_name"],"token" => $existToken
            ,"help_channel_id"=>0
            ,"support"=>""
            ));
        }
        try {
            $this->db->insert('users', array(
                'user' => $phone,
                'token' => $token
                // ,'join_coin'=>$this->defaults["coin_per_reg"]
                // ,'last_coin_date'=> new DateTime()
            ));
        } catch (\MeekroDBException $e) {
            return $this->error($response, "شماره شما تکراری است");

        }
        return $this->getResponse($response, array("channel_id"=>0,
            "channel_name"=>$this->defaults["channel_name"]
        ,"token" => $token
        ,"help_channel_id"=>0
            // ,'joinCoins'=>$this->defaults["coin_per_reg"]
        ,"support"=>""));
    }


    public function winners(Request $request, Response $response, $session, $args) {

        $history = $this->db->query("SELECT  user, amount FROM winners");
        return $this->getResponse($response,$history);
    }



    public function history(Request $request, Response $response, $session, $args) {

        $history = $this->db->query("SELECT  status,name, total, done, `left`, 2 AS type, create_date AS date FROM channels WHERE owner_id = %i AND status <> 3 ORDER BY create_date DESC",$session->id );
        return $this->getResponse($response,$history);
    }


    public function getComp(Request $request, Response $response, $session, $args) {
        $count = 0;

        $history = array(
            "isCompEnabled"=>$this->defaults["comp_enabled"]?true:false,

            "isWinnersEnabled"=>$this->defaults["winners_enabled"]?true:false,


            "compInfo"=>$this->defaults["comp_info"],
            "count"=>0
        );
        try{
            $count = $this->db->queryFirstField("SELECT  count(*) FROM comp_reg WHERE user = %s AND DATE(create_date) = CURRENT_DATE",$session->name);
            if(!$history["isCompEnabled"]){
                $history["alert"]=$this->defaults["comp_alert"];
            }

            $history["count"]=$count;

            if($count >= $this->defaults["comp_count"]){

                $history["alert"]="درخواست شما برای امروز کامل شده است لطفا روز بعد درخواست دهید";
                $history["isCompEnabled"] = false;
                $history["isWinnersEnabled"] = false;
                $history["count"]=0;
            }
        }catch (\MeekroDBException $e) {
            return $this->error($response, $e->getMessage());

        }
        return $this->getResponse($response,$history);
    }


    public function reg(Request $request, Response $response, $session, $args) {

        $check_row = $this->db->queryFirstField("SELECT count(*) FROM comp_reg WHERE user = $session->name AND check_day = 0");

        if ($check_row >= $this->defaults["comp_count"]){
            return $this->error($response, "درخواست شما برای امروز کامل شده است لطفا روز بعد درخواست دهید");

        } else {

            try{
                $price = $this->defaults["comp_pay"];
                $this->db->update('users', array(
                    'join_coin' => $session->join_coin - $price,
                ), "id=%d", $session->id);

                $this->db->insert('comp_reg', array(
                    'user' => $session->name,
                    'amount' => $price
                ));
            }catch (\MeekroDBException $e) {
                return $this->error($response, "خطا در ثبت نام");

            }
            return $this->getResponse($response, array("joinCoinsLost" => $price,"joinCoins" => $session->join_coin - $price ));
        }
    }
    public function hello(Request $request, Response $response, UserSession $session, $args) {
        $response->write("Hello, ".$args["name"] .$session["user"].", With ID: ".$session["id"]);
        return $response;
    }

    public function ref(Request $request, Response $response, UserSession $session, $args) {
        //your code
        //  return $this->error($response, "ثبت معرف تا اطلاع ثانوی غیر فعال می‌باشد");
        $upId =  $this->db->queryFirstField("SELECT id FROM users WHERE user = %s",$args["upLine"]);
        if($session->up_line != null || $session->up_line != 0){
            return $this->error($response, "شما معرف را قبلا ثبت کردید");
        }
        if($upId){
            if($upId == $session->id){
                return $this->error($response, "خودتان نمی توانید معرف خود شوید");
            }
            $this->db->startTransaction();
            $this->db->query("UPDATE users SET join_coin = join_coin + 50 WHERE id=%i",$upId);

            $this->db->update('users', array(
                'up_line' =>  $upId,
            ),"id=%i",$session->id);
            $this->db->commit();
            return $this->getResponse($response,$args["upLine"]);

        }
        return $this->error($response, "این معرف وجود ندارد"); 

    }

    public function log(Request $request, Response $response, UserSession $session, $args) {
        //your code
        $body = $request->getParsedBody();
        try {
            $body["user_id"] = $session->id;
            $this->db->insert('log', $body);
            return $this->getResponse($response, true);
        }catch (\Exception $e){

            return $this->error($response, "خطا");
        }
        return $this->error($response, "خطا");


    }


    public function myCharges(Request $request, Response $response, $session, $args) {
        $limit ="";
        if(isset($args["from"])){
            $from = $args["from"];
            if(isset($args["to"])){

            }
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT info, code as coins_price, type ,  use_date FROM charge, charge_type WHERE type_id = charge_type.id AND user_id = %i ORDER BY charge.use_date DESC".$limit, $session->id );
        return $this->getResponse($response,$history);
    }

    function startsWith($haystack, $needle) {
        // search backwards starting from haystack length characters from the end
        return $needle === "" || strrpos($haystack, $needle, -strlen($haystack)) !== false;
    }

}
