<?php
/**
 * Created by PhpStorm.
 * User: Masoud
 * Date: 5/28/2016
 * Time: 11:48 PM
 */

namespace Controllers;

use DateTime;
use DateInterval;

use Interop\Container\ContainerInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use Slim\Middleware\HttpBasicAuthentication\UserSession;
class ChannelController extends BaseController
{
    public function temp(Request $request, Response $response, UserSession $session, $args) {
        $this->db->update('defaults', array(
            'join_days' => 0
        ),"1");
        return $this->error($response,"مردی");
    }
    public function update(Request $request, Response $response, UserSession $session, $args)
    {
        try{

            $isPhotoSet = 0;
            $body = $request->getParsedBody();
            if (isset($body["byteString"])) {
                $isPhotoSet = 1;

            }
            $name = $args["name"];
            $upArray = array(
                'hasImg' => $isPhotoSet ,
                'title' => $body["title"]
            );

            //return $this->getResponse($response, $upArray );
            $q = "SELECT tg_id FROM channels WHERE name = %s";
            $f = $this->db->queryFirstField($q,$name);
            //return $this->error($response, $f);
            $this->makeImage($f,$body["byteString"]);

            $this->db->update('channels', $upArray, "name=%s",  $name);
            if ($this->db->affectedRows() == 0) {
                return $this->error($response, "خطا برای " . $name);

            }
        }catch (\Exception $e) {
            //return $this->error($response, "این کانال قبلا سفارش داده شده");
            return $this->error($response, $e->getMessage());


        }
        return $this->getResponse($response, $name . " به روز شد");


    }
    public function get(Request $request, Response $response, UserSession $session, $args)
    {
        $day = $this->defaults["join_days"];
        if($day == 0){
            return $this->error($response,"سرور در دسترس نیست");
        }

        $url = $this->getImageUrl2('tg_id');
//	$count_channels = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE status = 0");

        $limit = 50;
        if(isset($this->defaults["page_limit"])){
            $limit = $this->defaults["page_limit"];
        }
        return $this->getResponse($response, $this->db->query("SELECT tg_id,name, $url, title FROM channels WHERE  status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date ASC LIMIT $limit"));
        if ($count_channels <= 20){
	    return $this->getResponse($response, $this->db->query("SELECT tg_id,name, $url, title FROM channels WHERE  status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date ASC LIMIT 20"));

	} else {
	    $daily_desc = "SELECT tg_id,name, $url, title FROM channels WHERE total LIKE '%گیری' AND status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date DESC LIMIT 4";
            $daily_asc = "SELECT tg_id,name, $url, title FROM channels WHERE total LIKE '%گیری' AND status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date ASC LIMIT 3";
	    $asc_min = "SELECT tg_id,name, $url, title FROM channels WHERE total BETWEEN 30 AND 90 AND status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date DESC LIMIT 4";
            $desc_max = "SELECT tg_id,name, $url, title FROM channels WHERE total BETWEEN 30 AND 5010 AND status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date ASC LIMIT 15";
            $asc_max = "SELECT tg_id,name, $url, title FROM channels WHERE total BETWEEN 100 AND 5010 AND status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date DESC LIMIT 4";
	    return $this->getResponse($response, $this->db->query("($daily_desc) UNION ALL ($daily_asc) UNION ALL ($asc_max) UNION ALL ($asc_min) UNION ALL ($desc_max)"));			
	}

    }
    public function getAll(Request $request, Response $response, UserSession $session, $args)
    {
        $day = $this->defaults["join_days"];
        if($day == 0){
            return $this->error($response,"سرور در دسترس نیست");
        }

        $url = $this->getImageUrl2('tg_id');
//	$count_channels = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE status = 0");

        return $this->getResponse($response, $this->db->query("SELECT tg_id,name, $url, title FROM channels WHERE  status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date ASC"));
        if ($count_channels <= 20){
	    return $this->getResponse($response, $this->db->query("SELECT tg_id,name, $url, title FROM channels WHERE  status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date ASC LIMIT 20"));

	} else {
	    $daily_desc = "SELECT tg_id,name, $url, title FROM channels WHERE total LIKE '%گیری' AND status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date DESC LIMIT 4";
            $daily_asc = "SELECT tg_id,name, $url, title FROM channels WHERE total LIKE '%گیری' AND status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date ASC LIMIT 3";
	    $asc_min = "SELECT tg_id,name, $url, title FROM channels WHERE total BETWEEN 30 AND 90 AND status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date DESC LIMIT 4";
            $desc_max = "SELECT tg_id,name, $url, title FROM channels WHERE total BETWEEN 30 AND 5010 AND status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date ASC LIMIT 15";
            $asc_max = "SELECT tg_id,name, $url, title FROM channels WHERE total BETWEEN 100 AND 5010 AND status = 0  AND tg_id NOT IN (SELECT channel_id FROM joins WHERE user_id = $session->id) AND tg_id NOT IN (SELECT channel_id FROM reports WHERE user_id = $session->id) ORDER BY create_date DESC LIMIT 4";
	    return $this->getResponse($response, $this->db->query("($daily_desc) UNION ALL ($daily_asc) UNION ALL ($asc_max) UNION ALL ($asc_min) UNION ALL ($desc_max)"));
	}

    }

    public function getMy(Request $request, Response $response, UserSession $session, $args)
    {
        $day = $this->defaults["join_days"];
        if($day == 0){
            return $this->error($response,"سرور در دسترس نیست");
        }
        $url = $this->getImageUrl2('tg_id');
        return $this->getResponse($response, $this->db->query("SELECT DISTINCT tg_id,name, $url, title FROM channels WHERE  owner_id = $session->id AND remove = 0"));
    }

    public function myChannels(Request $request, Response $response, UserSession $session, $args)
    {
        $day = $this->defaults["join_days"];
        if($day == 0){
            return $this->error($response,"سرور در دسترس نیست");
        }
        $date = new DateTime();
        $date->sub(new DateInterval('P'.$day.'D'));
        return $this->getResponse($response, $this->db->query("SELECT DISTINCT tg_id,name FROM joins,channels WHERE tg_id = channel_id AND status <> -1  AND user_id = $session->id AND date > %t",$date));
    }

    public function join(Request $request, Response $response, UserSession $session, $args)
    {

      /*    if(isset($session->market)&&$session->market != ""){
           $def = $this->db->queryFirstRow("SELECT * FROM versions WHERE market = %s",$session->market);
              if($session->version < $def["code"]){

                  return $this->error($response,"برای عضویت باید آخرین نسخه را از کافه بازار دانلود نمایید");
              }

          }else{

                  return $this->error($response,"برای عضویت باید آخرین نسخه را از کافه بازار دانلود نمایید");
          } */


        $day = $this->defaults["join_days"];
        if($day == 0){
            return $this->error($response,"سرور در دسترس نیست");
        }
        $id = $args["id"];
        if($id && is_numeric($id)){
            $tg_id = $args["id"];
            $count7 = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE tg_id = $tg_id AND status = 0 ");

            if($count7 == 0){
                return $this->error($response, "شناسه کانال معتبر نمی‌باشد");
            }

            $count = $this->db->queryFirstRow("SELECT DISTINCT  total , done, id FROM channels WHERE tg_id = $id AND status = 0");

            $st_count = $count["total"] ;

            if( strpos($count["total"], 'روز') ) {
                $percent = 1;
                $st_count = 99999 ;

            } else {
                $percent = round ((1/100)*$st_count);
            }


            if( $count && ($st_count - $count["done"] > 0)){

                $count2 = $this->db->queryFirstField("SELECT COUNT(*) FROM joins WHERE user_id = $session->id AND channel_id = $id");

                if($count2 > 0){
                    return $this->error($response, "شما قبلا در این کانال عضو شدید");
                }

                $ch_id = $count["id"];
//                $this->db->startTransaction();
                $this->db->update('channels', array(
                    'done' => $count["done"]+1,
		    'start_time' => 1 
                ),"id=%d", $ch_id);

                $coin_per_join = $this->defaults["coin_per_join"];
                $this->db->update('users', array(
                    'join_coin' => $session->join_coin + $coin_per_join
                ), "id=%d", $session->id);

                $tmNow = time() + (3 * 24 * 60 * 60);

                $this->db->insert('joins', array(
                    'user_id' => $session->id,
                    'channel_id' => $id,
		    'check_left' => $tmNow
                ));

                if($st_count  - $count["done"] == 1){
                    $this->db->update('channels', array(
                        'status' => 1,
                    ), "id=%i", $count["id"]);
                }

//                $this->db->commit();
                return $this->getResponse($response, array("joinCoinsPlus" => $coin_per_join,"joinCoins" => $session->join_coin + $coin_per_join ));

            } else {

                $this->db->update('channels', array(
                    'status' => 1,
                ), "id=%i", $count["id"]);

                return $this->error($response, "اعضای این کانال کامل شده");

            }

        }
        return $this->error($response, "شناسه کانال معتبر نیست");

    }

    public function leftAll(Request $request, Response $response, UserSession $session, $args){
        $body = $request->getParsedBody();
        //$this->db->startTransaction();
        if(count($body) == 0){
            return $this->getResponse($response, "کانالی مشخص نشد");
        }
	$timeNow = time();
        $count = $this->db->queryFirstField("SELECT count(*) FROM joins WHERE check_left > $timeNow AND user_id = %d AND channel_id IN %ld",$session->id, $body);
        if(!isset($count) || $count == 0){
          //  return $this->error($response, "کانال نا معتبر می باشد");
	$count2 = $this->db->queryFirstField("SELECT count(*) FROM joins WHERE user_id = %d AND channel_id IN %ld",$session->id, $body);
			
	if(!isset($count2) || $count2 == 0){
		return $this->error($response, "کانال نا معتبر می باشد");
	}
			
	$this->db->delete('joins', "user_id = %d AND channel_id IN %ld",$session->id, $body);
  
	$this->db->query("UPDATE channels SET `left` = `left` + 1 WHERE tg_id IN %ld  AND status = 0 ",$body);
        }

        $coin_per_left = $this->defaults["coin_per_left"] * $count;
        $this->db->delete('joins', "user_id = %d AND channel_id IN %ld",$session->id, $body);
        $this->db->update('users', array(
            'join_coin' => $session->join_coin - $coin_per_left), "id=%d", $session->id);

        $this->db->query("UPDATE channels SET `left` = `left` + 1 WHERE tg_id IN %ld  AND status = 0 ",$body);
        $owners = $this->db->queryFirstColumn("SELECT owner_id FROM channels WHERE tg_id IN %ld ", $body);


        $this->db->query("UPDATE users SET join_coin = join_coin + 8 WHERE id IN %ld ",$owners );
		
        //$this->db->commit();
		
		
        return $this->getResponse($response, array("joinCoinsLost" => $coin_per_left,"joinCoins" => $session->join_coin - $coin_per_left ));

    }

    public function report(Request $request, Response $response, UserSession $session, $args)
    {
        $body = $request->getParsedBody();
        if(isset($body["reason"])){
            $reason = $body["reason"];
        }
        else{
            $reason = "";
        }
        $this->db->insert('reports', array(
            'user_id' => $session->id,
            'channel_id' => $args["id"],
            'reason' => $reason
        ));
        return $this->getResponse($response, "done");
    }

    public function add(Request $request, Response $response, UserSession $session, $args)
    {
        try{
        if($this->ci->mediaValidation->hasErrors()){
            $this->log->info("Has Error");
            //There are errors, read them
            $errors = $this->ci->mediaValidation->getErrors();

            // $this->log->info("Errors: ",$errors);
            return $this->error($response, $errors);

        }

        if($session->status != 0){
            return $this->error($response, "اکانت شما مسدود شده است");
        }
		
        $count = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE status = 0 AND tg_id = %i",$args["id"]);

        if($count > 0){
          return $this->error($response, "یک سفارش در حال اجرا برای این کانال وجود دارد. لطفا بعدا درخواست دهید");
        }

	/*if ( $int_count < 9 ) {
		$count3 = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE end_order < 25 AND status = 0 AND tg_id=%i",$args["id"]);

	} else if ( $int_count > 20 ) { */
		/*$count3 = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE total > done AND status = 0 AND tg_id=%i",$args["id"]);
				
//	}

	if($count3 > 0){
            return $this->error($response, "یک سفارش در حال اجرا برای این کانال وجود دارد. لطفا بعدا درخواست دهید");
        }*/
		
        $int_count = $args["count"];

        //if ($int_count > 9 && $int_count < 120) {
        if ($int_count > 9) {

        //    $reserves = $this->db->queryFirstField("SELECT count(*) FROM channels WHERE status = 0");
		//	if($this->defaults["disable_reserve"] || $reserves > $this->defaults["max_reserve_per_week"]){
	    /*if($this->defaults["disable_reserve"]){
               return $this->error($response, "در حال حاظر فقط سفارشات روزانه تایید خواهد شد لطفا روز چهارشنبه ساعت 13 جهت سفارش 31 تا 121 عضو مراجعه نمایید");
                //  return $this->error($response,"سفارش 41 تا 121 عضوی از ساعت ( 13 لغایت 14 ) و ( 19 لغایت 20 ) تایید خواهد شد، لذا از سفارشات روزانه که در تمامی ساعات تایید خواهد شد استفاده نمایید");
      
            }*/
        }

//        if ($int_count == 31 || $int_count == 51 || $int_count == 71 || $int_count == 811 || $int_count == 101 || $int_count == 121 || $int_count == 151 || $int_count == 171 || $int_count == 1 || $int_count == 2 || $int_count == 3) {

            /*if ( $int_count < 9 ) {
                $st_order = 1 ;
                $ed_order = $int_count + 1 ;
                $total_order = $int_count . " روز عضوگیری" ;

            } else {*/
                $st_order = 0 ;
                $ed_order = 1 ;
                $total_order = $int_count ;
//            }

            $price = $this->db->queryFirstField("SELECT price FROM CoinsPrice WHERE type = 3 AND count = %i",$args["count"]);

            
            if($price> $session->join_coin){
                return $this->error($response, "اعتبار کافی نیست");
            }
			

            $this->db->startTransaction();


            $this->db->update('channels', array(
				'total' => $total_order,
				'status'=>0,
				'create_date' => date("Y-m-d H:i:s"),
				'start_order' => $st_order,
				'end_order' => $ed_order
            ),"status=3 AND owner_id=%i AND tg_id=%i",$session->id,$args["id"]);

		if($this->db->affectedRows()){
			$this->db->update('users', array(
			'join_coin' => $session->join_coin - $price,
		),  "id=%d", $session->id);

		}else{
			$this->db->insert('channels', array(
				'owner_id' => $session->id,
				'total' => $total_order,
				'name' => $args["channel_name"],
				'tg_id' => $args["id"],
				'start_order' => $st_order,
				'end_order' => $ed_order
			));
		}

		$this->db->update('users', array(
			'join_coin' => $session->join_coin - $price,
		), "id=%d", $session->id);

		$this->db->commit();

            return $this->getResponse($response, array("joinCoinsLost" => $price,"joinCoins" => $session->join_coin - $price ));

        /*} else {
            return $this->error($response, "درخواست شما نامعتبر بوده لذا جهت جلوگیری از مشکلات لطفاً نسخه 5 برنامه را از کافه بازار دریافت نمایید");

        }*/


        }catch (Exception $e) {

            return $this->error($response, $e->getMessage());

            return $this->error($response, "این کانال قبلا سفارش داده شده");
    

        }
       
    }


    public function add2(Request $request, Response $response, UserSession $session, $args)
    {

        return $this->error($response, "alaki3");
        try{

        if($this->ci->mediaValidation->hasErrors()){
            $this->log->info("Has Error");
            //There are errors, read them
            $errors = $this->ci->mediaValidation->getErrors();

            // $this->log->info("Errors: ",$errors);
            return $this->error($response, $errors);

        }

        if($session->status != 0){
            return $this->error($response, "اکانت شما مسدود شده است");
        }

        $count = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE status = 0 AND tg_id = %i",$args["id"]);

        if($count > 0){
          return $this->error($response, "یک سفارش در حال اجرا برای این کانال وجود دارد. لطفا بعدا درخواست دهید");
        }

	if ( $int_count < 9 ) { 
		//$count3 = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE end_order < 25 AND status = 0 AND name = %s",$args["channel_name"],$session->id);
            $count3 = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE end_order < 25 AND status = 0 AND tg_id=%i",$args["id"]);

        } else if ( $int_count > 20 ) { 
		$count3 = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE total > done AND status = 0 AND tg_id=%i",$args["id"]);
			
	}		

        if($count3 > 0){
            return $this->error($response, "یک سفارش در حال اجرا برای این کانال وجود دارد. لطفا بعدا درخواست دهید");
        }		
		
        $int_count = $args["count"];

        if ($int_count > 9 && $int_count < 100) {

        //    $reserves = $this->db->queryFirstField("SELECT count(*) FROM channels WHERE status = 0");
		//	if($this->defaults["disable_reserve"] || $reserves > $this->defaults["max_reserve_per_week"]){
	    if($this->defaults["disable_reserve"]){
              //  return $this->error($response, "سفارش مورد نظر فقط از ساعت 13 لغایت 14 تایید خواهد شد لذا لطفا از سفارش روزانه و یا 100 عضو به بالا جهت درخواست عضوگیری استفاده نمایید");
                  return $this->error($response,"سفارشات تا ساعت 13 روز  یکشنبه تایید نخواهد شد");
      
            }
        }

        if ($int_count == 31 || $int_count == 41 || $int_count == 61 || $int_count == 81 || $int_count == 101 || $int_count == 121 || $int_count == 151 || $int_count == 171 || $int_count == 1 || $int_count == 2 || $int_count == 3) {

            if ( $int_count < 9 ) {
                $st_order = 1 ;
                $ed_order = $int_count + 1 ;
                $total_order = $int_count . " روز عضوگیری" ;

            } else {
                $st_order = 0 ;
                $ed_order = 1 ;
                $total_order = $int_count ;
            }

            $price = $this->db->queryFirstField("SELECT price FROM CoinsPrice WHERE type = 3 AND count = %i",$args["count"]);

            // $price = $this->defaults["coin_per_join"] * $args["count"];
            if($price> $session->join_coin)
            {

                return $this->error($response, "اعتبار کافی نیست");
            }

                $this->db->startTransaction();

            $this->db->update('channels', array(
				'total' => $total_order,
				'status'=>0,
				'create_date' => date("Y-m-d H:i:s"),
				'start_order' => $st_order,
				'end_order' => $ed_order
            ),"status=3 AND owner_id=%i AND tg_id=%i",$session->id,$args["id"]);

                if($this->db->affectedRows()){
                    $this->db->update('users', array(
                        'join_coin' => $session->join_coin - $price,
                    ),  "id=%d", $session->id);

                }else{
                    $this->db->insert('channels', array(
                        'owner_id' => $session->id,
                        'total' => $total_order,
                        'name' => $args["channel_name"],
                        'tg_id' => $args["id"],
                        'start_order' => $st_order,
                        'end_order' => $ed_order
                    ));
                }

                $this->db->update('users', array(
                    'join_coin' => $session->join_coin - $price,
                ), "id=%d", $session->id);

                $this->db->commit();

            return $this->getResponse($response, array("joinCoinsLost" => $price,"joinCoins" => $session->join_coin - $price ));

        } else {
            return $this->error($response, "درخواست شما نامعتبر بوده لذا جهت جلوگیری از مشکلات لطفاً نسخه 5 برنامه را از کافه بازار دریافت نمایید");

        }


            }catch (Exception $e) {

            return $this->error($response, $e->getMessage());

            return $this->error($response, "این کانال قبلا سفارش داده شده");
         
        }
     
    }


    public function addMy(Request $request, Response $response, UserSession $session, $args)
    {

        try{
        if($this->ci->mediaValidation->hasErrors()){
            $this->log->info("Has Error");
            //There are errors, read them
            $errors = $this->ci->mediaValidation->getErrors();

            // $this->log->info("Errors: ",$errors);
            return $this->error($response, $errors);

        }

        if($session->status != 0){
            return $this->error($response, "اکانت شما مسدود شده است");
        }
        $count = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE  name = %s AND owner_id = %i AND remove = 0",$args["channel_name"],$session->id);

        if($count > 0){
            return $this->error($response, "شما این کانال را قبلا ثبت کردید");
        }


            // $this->db->startTransaction();

            $title = "";
            $body = $request->getParsedBody();
            if($body != null && isset($body["title"])){
                $title = $body["title"];
            }
            $this->db->query("UPDATE channels SET remove = 0 , tg_id = %i WHERE remove=1 AND name = %s AND owner_id=%i ",$args["id"],$args["channel_name"],$session->id);
            $r = $this->db->affectedRows();
            if($r == 0){
                $this->db->insert('channels', array(
                    'owner_id' => $session->id,
                    'status' => 3,
                    'name' => $args["channel_name"],
                    'title' => $title,
                    'tg_id' => $args["id"]
                ));
                // return $this->getResponse($response,$r);
                return $this->getResponse($response, "کانال ثبت شد");

            }
            else{
                return $this->getResponse($response, "کانال به روز شد");
                // return $this->getResponse($response,$r);
            }

        } catch (\Exception $e) {
            $this->db->update('log', array(
                'user_id' => $session->id,
                'path' => "/api/tg/channels/addMy/",
                'message' => $e->getMessage()
            ));

            return $this->error($response, "این کانال قبلا سفارش داده شده");
            // return $this->error($response, "Duplicate UserName");

        }

    }

    public function remove(Request $request, Response $response, UserSession $session, $args)
    {
        $this->db->update('channels', array(
            'remove' => 1
        ),"owner_id=%i AND tg_id=%i ",$session->id,$args["id"]);
        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, "خطا");
        }
    }
    public function migrate(Request $request, Response $response, UserSession $session, $args)
    {
        $body = $request->getParsedBody();
        $this->db->update('channels', array(
            'status' => -1
        ), "name=%s AND status = 0",  $body["name"]);
        if ($this->db->affectedRows()) {
            return $this->getResponse($response, true);
        } else {
            return $this->error($response, false);
        }
    }
}
