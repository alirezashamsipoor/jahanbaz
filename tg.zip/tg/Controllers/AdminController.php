<?php
/**
 * Created by PhpStorm.
 * User: Masoud
 * Date: 5/28/2016
 * Time: 11:48 PM
 */

namespace Controllers;


use Interop\Container\ContainerInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use Slim\Middleware\HttpBasicAuthentication\UserSession;

class AdminController extends BaseController
{
    public function login(Request $request, Response $response, $session, $args) {

        $phone = $args["user"];
        $existToken = $this->db->queryFirstField("SELECT token FROM users WHERE user = %s",$phone);
        if($existToken){
            return $this->getResponse($response, array("channel_id"=>$this->defaults["channel_id"],"token" => $existToken));
        }

        return $this->error($response, "شناسه معتبر نیست");


    }


    public function message(Request $request, Response $response, $session, $args) {

        $body = $request->getParsedBody();
        if(isset($body["message"])){
            $this->db->insert("messages",array("message"=>$body["message"]));

        }
//      $existToken = $this->db->queryFirstField("SELECT token FROM users WHERE user = %s",$phone);
        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, "خطا");
        }

    }

    public function getDefaults(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }

        return $this->getResponse($response,$this->defaults);


    }
    public function setDefault(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }

        $val = $args["value"];
        $key = "";
        switch ($args["type"]) {
            case 1:
                $key = "coin_per_day";
                break;

            case 2:
                $key = "coin_per_reg";
                break;

            case 3:
                $key = "join_days";
                break;

            default:
                return $this->error($response, "نوع غیر معتبر");
                break;
        }

        $this->db->update("defaults",array(
            $key => $val
        ),"1=1");

        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, "خطا");
        }


    }

    public function joinHistory(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"])){
            $from = $args["from"];
            if(isset($args["to"])){

            }
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT users.user , his.name, his.total, his.done, his.left ,  his.create_date, his.status, his.id AS channel_id 
FROM users ,(SELECT name, total, done,`left`, create_date, owner_id, status, id 
FROM channels WHERE channels.status = 0) AS his WHERE his.owner_id = users.id ORDER BY create_date DESC".$limit );
        return $this->getResponse($response,$history);
    }

    public function doneHistory(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"])){
            $from = $args["from"];
            if(isset($args["to"])){

            }
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT users.user , his.name, his.total, his.done, his.left ,  his.create_date, his.status, his.id AS channel_id FROM users ,(SELECT name, total, done,`left`, create_date, owner_id, status, id FROM channels WHERE channels.status = 1 || total = done AND total > 0) AS his WHERE his.owner_id = users.id ORDER BY create_date DESC".$limit );
        return $this->getResponse($response,$history);
    }

    public function blockedHistory(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"])){
            $from = $args["from"];
            if(isset($args["to"])){

            }
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT users.user , his.name, his.total, his.done, his.left ,  his.create_date, his.status, his.id AS channel_id FROM users ,(SELECT name, total, done,`left`, create_date, owner_id, status, id FROM channels WHERE status = 2) AS his WHERE his.owner_id = users.id  ORDER BY create_date DESC".$limit );
        return $this->getResponse($response,$history);
    }

    public function viewHistory(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"]) && isset($args["to"])){
            $from = $args["from"];
            $to = $args["to"];
            //kjg
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT users.user , his.name,message_id, his.total, his.done ,his.desc,his.create_date, his.status, his.id AS channel_id , post_id FROM users , 
(SELECT  view_orders.id , name, message_id, `desc`,view_orders.status , view_orders.total, view_orders.done, view_orders.create_date, view_orders.owner_id, posts.id as post_id FROM channels
 JOIN posts ON channels.tg_id = posts.channel_id 
 JOIN view_orders ON posts.id = view_orders.post_id WHERE view_orders.status = 0 AND posts.status = 0 GROUP BY posts.id
 ) AS his
 WHERE his.owner_id = users.id ORDER BY create_date DESC".$limit );
        return $this->getResponse($response,$history);
    }

    public function doneViewHistory(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"])){
            $from = $args["from"];
            if(isset($args["to"])){

            }
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT users.user , his.name,message_id, his.total, his.done ,his.desc,his.create_date, his.status, his.id AS channel_id , post_id FROM users , 
(SELECT  view_orders.id , name, message_id, `desc`,view_orders.status , view_orders.total, view_orders.done, view_orders.create_date, view_orders.owner_id, posts.id as post_id FROM channels
 JOIN posts ON channels.tg_id = posts.channel_id 
 JOIN view_orders ON posts.id = view_orders.post_id WHERE view_orders.status = 1 AND posts.status = 0 GROUP BY posts.id
 ) AS his
 WHERE his.owner_id = users.id ORDER BY create_date DESC".$limit );
        return $this->getResponse($response,$history);
        //
    }

    public function blockedViewHistory(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"])){
            $from = $args["from"];
            if(isset($args["to"])){

            }
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT users.user , his.name,message_id, his.total, his.done ,his.desc,his.create_date, his.status, his.id AS channel_id , post_id FROM users , 
(SELECT  view_orders.id , name, message_id, `desc`,view_orders.status , view_orders.total, view_orders.done, view_orders.create_date, view_orders.owner_id, posts.id as post_id FROM channels
 JOIN posts ON channels.tg_id = posts.channel_id 
 JOIN view_orders ON posts.id = view_orders.post_id WHERE view_orders.status = 2 GROUP BY posts.id
 ) AS his
 WHERE his.owner_id = users.id ORDER BY create_date DESC".$limit );
        return $this->getResponse($response,$history);
    }


    public function reportHistoryNew(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"]) && isset($args["to"])){
            $from = $args["from"];
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT reports.id, users.user , channels.name, channels.tg_id, channels.id AS channel_id, channels.status, reason ,reports.create_date FROM users , channels , reports WHERE reports.user_id = users.id AND reports.channel_id = channels.tg_id AND new = 1 AND channels.status = 0 ORDER BY create_date DESC".$limit );
        return $this->getResponse($response,$history);
    }

    public function reportViewHistoryNew(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"]) && isset($args["to"])){
            $from = $args["from"];
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT post_reports.id, users.user , channels.name, channels.tg_id, channels.id AS channel_id, channels.status, reason ,post_reports.create_date FROM users , channels, posts , post_reports WHERE post_reports.user_id = users.id AND post_reports.post_id = posts.id AND channels.tg_id = posts.channel_id AND new = 1 AND channels.status = 0 ORDER BY create_date DESC".$limit );
        return $this->getResponse($response,$history);
    }

    public function reportHistoryAll(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"]) && isset($args["to"])){
            $from = $args["from"];
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT reports.id, users.user , channels.name, channels.tg_id, channels.id AS channel_id,channels.status, reason ,reports.create_date, new FROM users , channels , reports WHERE reports.user_id = users.id AND reports.channel_id = channels.tg_id AND new = 0 AND channels.status = 0 ORDER BY create_date DESC".$limit );
        return $this->getResponse($response,$history);
    }


    public function getUsers(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"]) && isset($args["to"])){
            $from = $args["from"];
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT members.id, user, view_coin, join_coin, members.create_date, GROUP_CONCAT(name SEPARATOR ',') AS channels FROM (SELECT users.id, user, view_coin, join_coin, users.create_date FROM users WHERE users.status = 0 AND users.role = 1) AS members LEFT JOIN channels ON members.id = channels.owner_id AND channels.status = 0  GROUP BY members.id ORDER BY members.create_date DESC".$limit );
        return $this->getResponse($response,$history);
    }


    public function getBlockedUsers(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"]) && isset($args["to"])){
            $from = $args["from"];
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT members.id, user, view_coin, join_coin, members.create_date, GROUP_CONCAT(name SEPARATOR ',') AS channels FROM (SELECT users.id, user, view_coin, join_coin, users.create_date FROM users WHERE users.status <> 0  AND users.role = 1) AS members LEFT JOIN channels ON members.id = channels.owner_id AND channels.status <> 0  GROUP BY members.id ORDER BY members.create_date DESC".$limit );
        return $this->getResponse($response,$history);
    }

    public function getUser(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT id, user, view_coin, join_coin, create_date, status FROM users WHERE user=%s",$args["id"] );
        return $this->getResponse($response,$history);
    }


    public function blockChannel(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $this->db->update("channels",array(
            "status" => 2
        ),"id=%i",$args["id"]);

        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, "خطا");
        }
    }

    public function changePassword(Request $request, Response $response, $session, $args) {

        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $this->db->update("users",array(
            "user" => $args["new"]
        ),"user=%s",$args["old"]);

        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, false);
        }
    }


    public function unblockChannel(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $channel = $this->db->queryFirstRow("SELECT total, done , status FROM channels WHERE id = %i",$args["id"]);
        $status = 2;
        if($channel["status"] == 3 ){
            $status = 3;
        }
        else if($channel["total"] > $channel["done"]){
            $status = 0;
        }
        $this->db->update("channels",array(
            "status" => $status
        ),"id=%i",$args["id"]);

        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, "خطا");
        }
    }

    public function blockUser(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $this->db->update("users",array(
            "status" => 1
        ),"id=%i",$args["id"]);

        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, "خطا");
        }
    }


    public function unblockUser(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $this->db->update("users",array(
            "status" => 0
        ),"id=%i",$args["id"]);

        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, "خطا");
        }
    }
    public function search(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $id = $args["id"];
        $q = "SELECT id, user, view_coin, join_coin, create_date, status FROM users WHERE user LIKE '%$id%'";
        // return $this->getResponse($response,$q);

        $history = $this->db->query($q);
        return $this->getResponse($response,$history);
    }

    public function removeChannel(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $this->db->delete('channels', "id=%i", $args["id"]);

        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, "خطا");
        }
        return $this->getResponse($response,$history);
    }

    public function searchChannel(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $name = $args["name"];

        $history = $this->db->query("SELECT users.user , his.name, his.total, his.done, his.left ,  his.create_date, his.status, his.id AS channel_id FROM users ,(SELECT name, total, done,`left`, create_date, owner_id, status, id FROM channels WHERE channels.name  LIKE '%$name%' AND channels.status <> 3) AS his WHERE his.owner_id = users.id ORDER BY create_date DESC" );
        return $this->getResponse($response,$history);
    }
    public function searchPost(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $name = $args["name"];

        $history = $this->db->query("SELECT users.user , his.name, his.total, his.done, his.message_id ,  his.create_date, his.status, his.id AS channel_id FROM users 
,(SELECT name, total, done,`left`, view_ordes.create_date, view_ordes.owner_id, view_ordes.status, id FROM channels
  JOIN posts ON channels.tg_id = posts.channel_id JOIN view_orders ON viewOrders.post_id = post . id 
 WHERE channels.name  LIKE '%$name%' AND channels.status <> 3 GROUP BY tg_id, posts.id) AS his WHERE his.owner_id = users.id ORDER BY create_date DESC" );
        return $this->getResponse($response,$history);
    }

    public function getUsersCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM users WHERE status = 0");
        return $this->getResponse($response,$history);
    }

    public function getChargesCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM charge WHERE used = 1");
        return $this->getResponse($response,$history);
    }

    public function getNewChargesCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM charge WHERE used = 0");
        return $this->getResponse($response,$history);
    }

    public function getBlockedUsersCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM users WHERE status <> 0");
        return $this->getResponse($response,$history);
    }


    public function getJoinCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE status = 0");
        return $this->getResponse($response,$history);
    }


    public function getDoneCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE status = 1");
        return $this->getResponse($response,$history);
    }


    public function getBlockedCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM channels WHERE status = 2");
        return $this->getResponse($response,$history);
    }

    public function getViewCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }

        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM users , 
(SELECT  view_orders.id , name, message_id, `desc`,view_orders.status , view_orders.total, view_orders.done, view_orders.create_date, view_orders.owner_id, posts.id as post_id FROM channels
 JOIN posts ON channels.tg_id = posts.channel_id 
 JOIN view_orders ON posts.id = view_orders.post_id WHERE view_orders.status = 0 AND posts.status = 0 GROUP BY posts.id
 ) AS his
 WHERE his.owner_id = users.id " );
//        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM view_orders WHERE status = 0");
        return $this->getResponse($response,$history);
    }


    public function getDoneViewCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM view_orders WHERE status = 1");
        return $this->getResponse($response,$history);
    }

    public function getBlockedViewCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM view_orders WHERE status = 2");
        return $this->getResponse($response,$history);
    }

    public function readReport(Request $request, Response $response, UserSession $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $id = $args["id"];
        $this->db->update("reports",array(
            "new" => 0
        ),"id=%i",$id);
        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, "خطا");
        }    }


    public function readPostReport(Request $request, Response $response, UserSession $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $id = $args["id"];
        $this->db->update("post_reports",array(
            "new" => 0
        ),"id=%i",$id);
        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, "خطا");
        }    }


    public function gift(Request $request, Response $response, UserSession $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $user = $args["user"];
        $type = $args["type"];
        $amount = $args["amount"];
        if($type == 1){
            $coin_type = "join_coin";
        }
        else if($type == 2){
            $coin_type = "view_coin";
        }
        $this->db->query("UPDATE users SET $coin_type = $coin_type + $amount WHERE user = %s",$user);
        if($this->db->affectedRows()){
            return $this->getResponse($response,true);
        }
        else{
            return $this->error($response, "سکه اهدا نشد");
        }
    }

    public function ref(Request $request, Response $response, UserSession $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        //your code
        $upId =  $this->db->queryFirstField("SELECT id FROM users WHERE user = %s",$args["upLine"]);
        if($upId){
            if($upId == $session->id){
                return $this->error($response, "خودتان نمی توانید معرف خود شوید");
            }
            $this->db->startTransaction();
            $this->db->query("UPDATE users SET view_coin = view_coin + 50 WHERE id=%i",$upId);

            $this->db->update('users', array(
                'up_line' =>  $upId,
            ),"id=%i",$session->id);
            $this->db->commit();
            return $this->getResponse($response,$args["upLine"]);

        }
        return $this->error($response, "این معرف وجود ندارد");

    }



    public function getCharges(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $limit ="";
        if(isset($args["from"])){
            $from = $args["from"];
            if(isset($args["to"])){

            }
            $to = $args["to"];
            $limit = " LIMIT $from,$to ";
        }
        $history = $this->db->query("SELECT info, code,  use_date, user FROM charge, charge_type, users WHERE type_id = charge_type.id AND user_id = users.id AND used = 1 ORDER BY charge.use_date DESC".$limit );
        return $this->getResponse($response,$history);
    }

    public function getChargeTypes(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }

        $history = $this->db->query("SELECT id, info FROM  charge_type");
        return $this->getResponse($response,$history);
    }

    public function addCharge(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }

        $this->db->insert("charge",array(
            "code"=>$args["code"],
            "type_id"=>$args["type"]
        ));
        return $this->getResponse($response,$this->db->affectedRows());
    }

    public function acceptPay(Request $request, Response $response, UserSession $session, $args)
    {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }

        try {
            $id = $args["id"];
            $info = $this->db->queryFirstRow("SELECT join_coin, amount, user_id FROM users, pay_log WHERE pay_log.id = %i  AND users.id = user_id", $id);

            if ($info["amount"] > $info["join_coin"]) {
                return $this->error($response, "موجودی سکه کافی نیست");
                //   return $this->error($response, $session->name);
            }


            $this->db->update("pay_log", array("paid" => 1, "pay_date"=> new \DateTime()), "id = %d", $args["id"]);
            $this->updateShitil($info["user_id"], -$info["amount"], $this->TYPE_PAY);
        }catch (\Exception $e){

            return $this->getResponse($response,array("hi"=>$e->getMessage()));
        }

        return $this->getResponseWithMessage($response,array(),"درخواست تایید شد." );
    }

    public function getPays(Request $request, Response $response, UserSession $session, $args)
    {

        try {
            if (!$session->isAdmin()) {
                return $this->error($response, "دسترسی غیر مجاز");
            }

            $limit = "";
            if (isset($args["from"])) {
                $from = $args["from"];
                if (isset($args["to"])) {
                    $to = $args["to"];
                    $limit = " LIMIT $from,$to ";
                }
                else{
                    $limit = " LIMIT $from";
                }
            }
//            return $this->error($response,$limit);

            $history = $this->db->query("SELECT amount,join_coin, name, date, pay_date, phone, paid, card_number AS card , pay_log.id FROM pay_log, users WHERE user_id = users.id AND paid = 0 ORDER BY date ASC" . $limit);
        }catch (\Exception $e){
//            return $this->error($response,$e->getMessage());
            return $this->getResponse($response,array("hi"=>$e->getMessage()));

        }
        return $this->getResponse($response,$history);
    }

    public function getPaid(Request $request, Response $response, UserSession $session, $args)
    {

        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }

        $limit = "";
        if (isset($args["from"])) {
            $from = $args["from"];
            if (isset($args["to"])) {
                $to = $args["to"];
                $limit = " LIMIT $from,$to ";
            }
            else{
                $limit = " LIMIT $from";
            }
        }
        $history = $this->db->query("SELECT amount,join_coin, name, date, pay_date, phone, paid, card_number AS card FROM pay_log, users WHERE user_id = users.id AND paid = 1 ORDER BY date ASC".$limit );
        return $this->getResponse($response,$history);
    }

    public function getPaidCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM pay_log WHERE paid = 1");
        return $this->getResponse($response,$history);
    }

    public function getPaysCount(Request $request, Response $response, $session, $args) {
        if(!$session->isAdmin()){
            return $this->error($response, "دسترسی غیر مجاز");
        }
        $history = $this->db->queryFirstField("SELECT COUNT(*) FROM pay_log WHERE paid = 0");
        return $this->getResponse($response,$history);
    }
}
