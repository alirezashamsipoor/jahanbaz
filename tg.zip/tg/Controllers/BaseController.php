<?php
/**
 * Created by PhpStorm.
 * User: Masoud
 * Date: 5/28/2016
 * Time: 11:48 PM
 */

namespace Controllers;


use Interop\Container\ContainerInterface;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;
use Slim\Middleware\HttpBasicAuthentication\UserSession;

class BaseController
{
    private $coin_type = ['transfare','gift','sub_line','wall','left','join','reserve_member','none','buy','reg','day','take', 'shitil', 'view', 'pay'];
    protected $TYPE_TRANSFARE = 0;
    protected $TYPE_GIFT = 1;
    protected $TYPE_SUB_LINE = 2;
    protected $TYPE_WALL = 3;
    protected $TYPE_LEFT = 4;
    protected $TYPE_JOIN = 5;
    protected $TYPE_RESERVE_MEMBER = 6;
    protected $TYPE_NONE = 7;
    protected $TYPE_BUY = 8;
    protected $TYPE_REG = 9;
    protected $TYPE_DAY = 10;
    protected $TYPE_TAKE = 11;
    protected $TYPE_SHITIL = 12;
    protected $TYPE_VIEW = 13;
    protected $TYPE_PAY = 14;

    protected $ci;
    protected $log;
    protected $db ;


    protected $IMG_PATH = "./img/";
    protected $IMG_URL = "http://tala-member.ir/api/tg/img/";

    //Constructor
    public function __construct(ContainerInterface $ci) {
        $this->ci = $ci;
        $this->db = $ci->db;
        // $this->log = $ci->log;
        $this->defaults = $ci->defaults;
    }

    public function error(Response $response, $message) {
        return $response->withStatus(500)->withJson($this->getResponseArray(true, $message));

    }

    public function getResponse(Response $response, $data) {
        return $response->withJson($this->getResponseArray(false, "", $data));

    }


    public function getResponseWithMessage(Response $response, $data, $message) {
        return $response->withJson($this->getResponseArray(false, $message, $data));

    }

    private function getResponseArray($error, $message, $data = null){
        return array(
            "error"=>$error,"message" => $message, "data"=>$data
        );
    }

protected function updateCoin($user_id, $amount, $type,$token, $justLog = false){
    
      
    
        if(is_array($user_id)){
            $this->db->update("users", array(
                "join_coin" => $this->db->sqleval("join_coin + " . $amount)
            ), "id IN %li", $user_id);
            $rows = array();
            foreach ($user_id as $value) {
                $rows[] = array(
                    'amount' => $amount,
                    'user_id' => $value,
        'token' => $token,
                    'type' => $this->coin_type[$type]
                );
            }
            $this->db->insert("coins_log", $rows);
        }
        else {
            if(!$justLog) {
                $this->db->update("users", array(
                    "join_coin" => $this->db->sqleval("join_coin + " . $amount)
                ), "id = %i", $user_id);
            }
            $this->db->insert("coins_log", array(
                "amount" => $amount,
                "user_id" => $user_id,
    "token" => $token,
                "type" => $this->coin_type[$type]
            ));
        }
    
	}
    


protected function updateViewCoin($user_id, $amount, $type){



        if(is_array($user_id)){
            $this->db->update("users", array(
                "join_coin" => $this->db->sqleval("join_coin + " . $amount)
            ), "id IN %li", $user_id);
            $rows = array();
            foreach ($user_id as $value) {
                $rows[] = array(
                    'amount' => $amount,
                    'user_id' => $value,
                    'type' => $this->coin_type[$type]
                );
            }
            $this->db->insert("coins_log", $rows);
        }
        else {
            $this->db->update("users", array(
                "join_coin" => $this->db->sqleval("join_coin + " . $amount)
            ), "id = %i", $user_id);
            $this->db->insert("coins_log", array(
                "amount" => $amount,
                "user_id" => $user_id,
                "type" => $this->coin_type[$type]
            ));
        }

	}




    protected function updateShitil($user_id, $amount, $type, $justLog = false){
        if(is_array($user_id)){
            $this->db->update("users", array(
                "join_coin" => $this->db->sqleval("join_coin + " . $amount)
            ), "id IN %li", $user_id);
            $rows = array();
            foreach ($user_id as $value) {
                $rows[] = array(
                    'amount' => $amount,
                    'user_id' => $value,
                    'type' => $this->coin_type[$type]
                );
            }
            $this->db->insert("shitil_log", $rows);
        }
        else {
            if(!$justLog) {
                $this->db->update("users", array(
                    "join_coin" => $this->db->sqleval("join_coin + " . $amount)
                ), "id = %i", $user_id);
            }
            $this->db->insert("shitil_log", array(
                "amount" => $amount,
                "user_id" => $user_id,
                "type" => $this->coin_type[$type]
            ));
        }
    }

    function startsWith($haystack, $needle) {
        // search backwards starting from haystack length characters from the end
        return $needle === "" || strrpos($haystack, $needle, -strlen($haystack)) !== false;
    }

public function makeImage($file,$byte){
//$echo $this->IMG_PATH.$file.".jpg";
        file_put_contents($this->IMG_PATH.$file.".jpg", base64_decode($byte));

    }

    public function getImageUrl($id){
        return " CONCAT('$this->IMG_URL',$id,'.jpg') AS byteString";
    }
public function getImageUrl2($id){
        return " IF( hasImg= 0 , \"\", CONCAT('$this->IMG_URL',$id,'.jpg')) AS byteString";
    }


    public function testCoin(Request $request, Response $response, UserSession $session, $args){
        $this->db->update("coinsprice",array(
            "description"=>"90000"
        ),"type = 1 AND count = 40000");
//        $this->db->insert("coinsprice",array("count"=>40000,"price"=>90000,"sku"=>"m10", "type"=>1, "info"=>40000));

        return $this->getResponse($response,"Done");
    }
}
