<?php

/**
 * Step 1: Require the Slim Framework using Composer's autoloader
 *
 * If you are not using Composer, you need to load Slim Framework with your own
 * PSR-4 autoloader.
 */

date_default_timezone_set('Asia/Tehran');
require '../vendor/autoload.php';
require 'MiddleWares/TrailingSlash.php';
require 'libs/HttpFullAuthentication.php';
require 'libs/TokenAuthenticator.php';
require 'libs/RequestResponseSession.php';
require 'libs/RequestPassThroughRule.php';
require 'libs/UserSession.php';
require 'init/BootStrap.php';
require 'Controllers/BaseController.php';
require 'Controllers/UserController.php';
require 'Controllers/ChannelController.php';
require 'Controllers/PostController.php';
require 'Controllers/CoinController.php';
require 'Controllers/AdminController.php';

use Controllers\ChannelController;
use Controllers\PostController;
use Controllers\UserController;
use Controllers\CoinController;
use Controllers\AdminController;

/**
 * Step 2: Instantiate a Slim application
 *
 * This example instantiates a Slim application using
 * its default settings. However, you will usually configure
 * your Slim application now by passing an associative array
 * of setting names and values into the application constructor.
 */
$app = new \SlimBootStrap\BootStrap();


//$app->add(new TrailingSlash());

/**
 * Step 3: Define the Slim application routes
 *
 * Here we define several Slim application routes that respond
 * to appropriate HTTP request methods. In this example, the second
 * argument for `Slim::get`, `Slim::post`, `Slim::put`, `Slim::patch`, and `Slim::delete`
 * is an anonymous function.
 */
//$app->get('/',);

$app->post('/channels/add/{id}/{channel_name}/{count}[/{title}]',  'Controllers\ChannelController'.':add');//->add($app->getContainer()->get('mediaValidation'));
$app->get('/channels/add2/{id}/{channel_name}/{count}[/{title}]',  'Controllers\ChannelController'.':add2');//->add($app->getContainer()->get('mediaValidation'));
$app->post('/channels/addMy/{id}/{channel_name}[/{title}]',  'Controllers\ChannelController'.':addMy');//->add($app->getContainer()->get('mediaValidation'));
$app->post('/channels/report/{id}',  'Controllers\ChannelController'.':report');//->add($app->getContainer()->get('mediaValidation'));
$app->get('/channels',  'Controllers\ChannelController'.':get');
$app->get('/channels/getAll',  'Controllers\ChannelController'.':getAll');
$app->get('/channels/getMy',  'Controllers\ChannelController'.':getMy');
$app->post('/channels/join/{id}',  'Controllers\ChannelController'.':join');
$app->get('/channels/self',  'Controllers\ChannelController'.':myChannels');
$app->post('/channels/leftAll',  'Controllers\ChannelController'.':leftAll');
$app->post('/channels/remove/{id}',  'Controllers\ChannelController'.':remove');
$app->post('/channels/temp',  'Controllers\ChannelController'.':temp');
$app->post('/channels/migrate', 'Controllers\ChannelController' . ':migrate');
$app->post('/channels/update/{name}', 'Controllers\ChannelController' . ':update');

$app->get('/newCoins', 'Controllers\BaseController' . ':testCoin');


$app->post('/user/login/{phone}',  'Controllers\UserController'.':login');
$app->post('/user/ref/{upLine}',  'Controllers\UserController'.':ref');
$app->post('/users/log',  'Controllers\UserController'.':log');
$app->get('/user/update',  'Controllers\UserController'.':update');
$app->get('/user/history',  'Controllers\UserController'.':history');

$app->get('/user/myCharges',  'Controllers\UserController'.':myCharges');

$app->get('/user/comp/get',  'Controllers\UserController'.':getComp');
$app->get('/user/comp/reg',  'Controllers\UserController'.':reg');
$app->get('/user/comp/winners',  'Controllers\UserController'.':winners');

$app->group('/admin', function () use ($app) {
    $app->post('/changePassword/{old}/{new}',  'Controllers\AdminController'.':changePassword');
    $app->post('/setDefault/{type}/{value}',  'Controllers\AdminController'.':setDefault');
    $app->get('/getDefaults',  'Controllers\AdminController'.':getDefaults');//
    $app->get('/joinHistory[/{from}/{to}]',  'Controllers\AdminController'.':joinHistory');
    $app->get('/viewHistory[/{from}/{to}]',  'Controllers\AdminController'.':viewHistory');
    $app->get('/doneHistory[/{from}/{to}]',  'Controllers\AdminController'.':doneHistory');
    $app->get('/doneViewHistory[/{from}/{to}]',  'Controllers\AdminController'.':doneViewHistory');
    $app->get('/blockedViewHistory[/{from}/{to}]',  'Controllers\AdminController'.':blockedViewHistory');
    $app->get('/blockedHistory[/{from}/{to}]',  'Controllers\AdminController'.':blockedHistory');
    $app->get('/reportHistoryAll[/{from}/{to}]',  'Controllers\AdminController'.':reportHistoryAll');
    $app->get('/reportHistoryNew[/{from}/{to}]',  'Controllers\AdminController'.':reportHistoryNew');
    $app->get('/reportPostHistoryNew[/{from}/{to}]',  'Controllers\AdminController'.':reportPostHistoryNew');
    $app->get('/getUsers[/{from}/{to}]',  'Controllers\AdminController'.':getUsers');
    $app->get('/getBlockedUsers[/{from}/{to}]',  'Controllers\AdminController'.':getBlockedUsers');
    $app->get('/getCharges[/{from}/{to}]',  'Controllers\AdminController'.':getCharges');
    $app->get('/getChargeTypes',  'Controllers\AdminController'.':getChargeTypes');
    $app->get('/addCharge/{type}/{code}',  'Controllers\AdminController'.':addCharge');
    $app->get('/getUser/{id}',  'Controllers\AdminController'.':getUser');
    $app->get('/search/{id}',  'Controllers\AdminController'.':search');
    $app->get('/searchChannel/{name}',  'Controllers\AdminController'.':searchChannel');
    $app->get('/searchPost/{name}',  'Controllers\AdminController'.':searchPost');
    $app->get('/removeChannel/{id}',  'Controllers\AdminController'.':removeChannel');
    $app->get('/removePost/{id}',  'Controllers\AdminController'.':removePost');
    $app->get('/blockChannel/{id}',  'Controllers\AdminController'.':blockChannel');
    $app->get('/blockPost/{id}',  'Controllers\AdminController'.':blockPost');
    $app->get('/blockUser/{id}',  'Controllers\AdminController'.':blockUser');
    $app->get('/unblockChannel/{id}',  'Controllers\AdminController'.':unblockChannel');
    $app->get('/unblockPost/{id}',  'Controllers\AdminController'.':unblockPost');
    $app->get('/unblockUser/{id}',  'Controllers\AdminController'.':unblockUser');
    $app->get('/getUsersCount',  'Controllers\AdminController'.':getUsersCount');
    $app->get('/getBlockedUsersCount',  'Controllers\AdminController'.':getBlockedUsersCount');
    $app->get('/getJoinCount',  'Controllers\AdminController'.':getJoinCount');
    $app->get('/getDoneCount',  'Controllers\AdminController'.':getDoneCount');
    $app->get('/getBlockedCount',  'Controllers\AdminController'.':getBlockedCount');
    $app->get('/getViewCount',  'Controllers\AdminController'.':getViewCount');
    $app->get('/getDoneViewCount',  'Controllers\AdminController'.':getDoneViewCount');
    $app->get('/getBlockedViewCount',  'Controllers\AdminController'.':getBlockedViewCount');
    $app->get('/getChargesCount',  'Controllers\AdminController'.':getChargesCount');
    $app->get('/getNewChargesCount',  'Controllers\AdminController'.':getNewChargesCount');
    $app->get('/gift/{type}/{user}/{amount}',  'Controllers\AdminController'.':gift');
    $app->get('/setCoinsPrice/{type}',  'Controllers\AdminController'.':setCoinsPrice');
    $app->get('/readReport/{id}',  'Controllers\AdminController'.':readReport');
    $app->get('/readPostReport/{id}',  'Controllers\AdminController'.':readPostReport');
    $app->get('/login/{user}',  'Controllers\AdminController'.':login');
    $app->post('/message',  'Controllers\AdminController'.':message');
    $app->post('/acceptPay/{id}',  'Controllers\AdminController'.':acceptPay');
    $app->get('/getPays[/{from}/{to}]', 'Controllers\AdminController' . ':getPays');
//    $app->get('/getPays', 'Controllers\AdminController' . ':getPays');
    $app->get('/getPaid[/{from}/{to}]', 'Controllers\AdminController' . ':getPaid');
    $app->get('/getPaysCount',  'Controllers\AdminController'.':getPaysCount');
    $app->get('/getPaidCount',  'Controllers\AdminController'.':getPaidCount');

})->add(function ($request, $response, $next) {
    // $response->getBody()->write('It is now ');
    $response = $next($request, $response);
    // $response->getBody()->write('. Enjoy!');

    return $response;
});

$app->post('/coin/transfare/{type}/{user}/{amount}',  'Controllers\CoinController'.':transfare');
$app->get('/coin',  'Controllers\CoinController'.':get');
$app->post('/coin/setCoinsPrice',  'Controllers\CoinController'.':setCoinsPrice');
$app->post('/coin/buyCoin/{id}[/{market}]',  'Controllers\CoinController'.':buyCoin2');
$app->post('/coin/buyCoin2/{id}[/{market}]',  'Controllers\CoinController'.':buyCoin2');
$app->get('/coin/getCoinsPrice',  'Controllers\CoinController'.':getCoinsPrice');
$app->get('/coin/getDefaultCoins',  'Controllers\CoinController'.':getDefaultCoins');
$app->get('/coin/getCharges',  'Controllers\CoinController'.':getCharges');
$app->get('/coin/buyCharge/{id}',  'Controllers\CoinController'.':buyCharge');
$app->post('/coin/shitil/{amount}', 'Controllers\CoinController' . ':shitil');
$app->post('/coin/adplay/{amount}', 'Controllers\CoinController' . ':adplay');
$app->post('/coin/payRequest', 'Controllers\CoinController' . ':payRequest');
$app->get('/coin/myPays', 'Controllers\CoinController' . ':myPays');

/*$app->post('/posts/add/{channel_name}/{message_id}/{count}',  'Controllers\PostController'.':add');//->add($app->getContainer()->get('mediaValidation'));
$app->post('/posts/accept/{channel_name}/{message_id}/{message_number}',  'Controllers\PostController'.':accept');
$app->get('/posts',  'Controllers\PostController'.':get');
$app->get('/posts/view/{id}',  'Controllers\PostController'.':view');*/
$app->group('/posts', function () use ($app) {



    $app->post('/add/{channel_id}/{message_id}/{total}', 'Controllers\PostController' . ':add');//->add($app->getContainer()->get('mediaValidation'));
//    $app->post('/accept/{channel_name}/{message_id}/{message_number}', 'Controllers\PostController' . ':accept');
    $app->get('/get',  'Controllers\PostController' . ':get');
    $app->get('/history',  'Controllers\PostController'. ':history');
    $app->get('/view/{id}', 'Controllers\PostController'. ':view');
    $app->post('/remove/{id}', 'Controllers\PostController'. ':remove');

});
$app->get('/hello[/{name}]', 'Controllers\UserController'.':hello')->setArgument('name', 'World!');
$app->get('/hi[/{name}]', function($request, $response,$session,  $args){

    $response->write("hi: " .  $args['name']);
    return $response;
})->setArgument('name', 'World!');

$app->get('/checkVersion/{code}[/{market}]', function ( $request,  $response,  $session, $args)
{
    if(!isset($args["market"])){
        $args["market"] = "bazaar";
    }
    $code = $args["code"];
    $this->db->update("users",array("version"=>$code ,"market"=>$args["market"]),"id=%i",$session->id);
    $def = $this->db->queryFirstRow("SELECT * FROM versions WHERE market = %s",$args["market"]);
    if($code < $def["code"]){
        $data = ["ok"=>false, "link"=>$def["link"], "changes"=>$def["changes"]
            ,"force"=>($def["force"]?true:false)
            ,"Server"=>$def["code"]
            ,"Your"=>$code];
    }
    else{
        $data["ok"] = true;
    }


    return $response->withJson(array(
        "error"=>false,"message" => "", "data"=>$data
    ));

});
/**
 * Step 4: Run the Slim application
 *
 * This method should be called last. This executes the Slim application
 * and returns the HTTP response to the HTTP client.
 */
$app->run();
