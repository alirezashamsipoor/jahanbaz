<?php
/**
 * Created by PhpStorm.
 * User: Masoud
 * Date: 6/17/2016
 * Time: 1:24 AM
 */

$host = 'localhost';

// $dbName = 'php';
// $username = 'adminr5UM9Q6';
// $password = 'lRRsUpg4JcSZ';

$dbName = 'tg';
$username = 'root';
$password = 't@l@Member';

$dsn = 'mysql:host='.$host.';dbname='.$dbName;
$options = array(
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
);
