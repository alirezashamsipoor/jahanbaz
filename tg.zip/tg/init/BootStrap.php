<?php

/**
 * Created by PhpStorm.
 * User: Masoud
 * Date: 5/26/2016
 * Time: 4:38 PM
 */


namespace SlimBootStrap;

use DB;
use MeekroDB;
use PDO;
use Slim\App;

use Middleware\TrailingSlash;
use Slim\Middleware\HttpBasicAuthentication\PdoAuthenticator;
use Slim\Middleware\HttpBasicAuthentication\TokenAuthenticator;
use Respect\Validation\Validator as v;

class BootStrap extends App
{

    private $config;
    private $pdo;
    public function __construct(){
        $this->initConfig();
        $this->initExceptionHandlers();
        $this->initMiddleWares();
        $this->initValidators();
        /*$this->config["settings"] = [
            'displayErrorDetails' => true,
        ];*/
//Override the default Not Found Handler
        /*$this->config['notFoundHandler'] = function ($c) {
            return function ($request, $response) use ($c) {
                return $c['response']
                    ->withStatus(404)
                    ->withHeader('Content-Type', 'text/html')
                    ->write('<h1>Page not found</h1>');
            };
        };*/



        parent::__construct($this->config);




    }

    private function initExceptionHandlers(){
        $this->config['errorHandler'] = function ($c) {
            return function ($request, $response, \Exception $exception) use ($c) {
                return $c['response']->withStatus(500)->withJson(array(
                    "error"=>true,"message" => "Server Error", "dev"=>$exception->getMessage()
                ));
            };
        };
    }

    private function initConfig(){

        $this->config = new \Slim\Container(); //Create Your container

        $this->config['foundHandler'] = function() {
            return new \Slim\Handlers\Strategies\RequestResponseSession();
        };


        require_once "db_config.php";
        
        $options = array(
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        );



        $this->config["setting"] = [
            "host" => $host,
            "dbName" => $dbName,
            "username" => $username,
            "password" => $password];

        $this->pdo = new PDO($dsn, $username, $password, $options);


        // $logger = new \Katzgrau\KLogger\Logger('/logs');
        // $logger->info('<<<<<<<<< Bootstrap Start >>>>>>>>>');
        // $this->config["log"] = $logger;
        DB::$user = $username;
        DB::$password = $password;
        DB::$dbName = $dbName;
        DB::$host = $host; //defaults to localhost if omitted
        DB::$error_handler = false; // since we're catching errors, don't need error handler
        DB::$throw_exception_on_error = true;
DB::$throw_exception_on_nonsql_error = true;
//        DB::$port = '12345'; // defaults to 3306 if omitted
        DB::$encoding = 'utf8';
//        $this->config["db"] = new MeekroDB($host, $username, $password, $dbName, null, 'utf8');
        $this->config["db"] = DB::getMDB();
        $this->config["defaults"] = $this->config["db"]->queryFirstRow("SELECT * FROM defaults");
    }

    private function initValidators(){
        $translator = function($message){
            $messages = [
                '{{name}} must contain only letters (a-z) and digits (0-9)' => '{{name}} فقط باید شامل حروف و اعداد باشد',
                'All of the required rules must pass for {{name}}' => 'All of the required rules must pass for {{name}}',
                '{{name}} must contain only letters (a-z), digits (0-9) and {{additionalChars}}' => '{{name}} فقط باید شامل حروف و اعداد باشد و {{additionalChars}}',
                '{{name}} must have a length between {{minValue}} and {{maxValue}}' => 'طول {{name}} باید بین  {{minValue}} و {{maxValue}} باشد',
                '{{name}} must be numeric' => '{{name}} باید عدد باشد',
                'The value must not be empty' => 'نباید خالی باشد',
                '{{name}} must not be empty' => '{{name}} نباید خالی باشد',
                '{{name}} must be greater than {{interval}}' => '{{name}} باید بزرگتر از {{interval}} باشد',
            ];
            return $messages[$message];
        };
           $this->config['mediaValidation'] = function () use($translator) {
            //Create the validators
            $ageValidator = v::numeric()->min(1);
            $validators = array(
                'tg_id' => $ageValidator,
                'owner_id' => $ageValidator,
                'count' => $ageValidator
            );

            return new \DavidePastore\Slim\Validation\Validation($validators,$translator);
        };
           $this->config['userValidation'] = function ()  use($translator) {
            //Create the validators
            $userValidator = v::notEmpty()->alnum();
            $validators = array(
                'user' => $userValidator,
            );

            return new \DavidePastore\Slim\Validation\Validation($validators);//,$translator);
        };
    }

    private function initMiddleWares(){


        parent::add(new TrailingSlash());

        parent::add(new \Slim\Middleware\HttpFullAuthentication([
            "passthrough" => ["/user/login","/admin/login"],
            "secure" => false,
            "authenticator" => new TokenAuthenticator([
                "pdo" => $this->pdo
            ], $this->config)
        ]));
        // parent::add(new \Slim\Middleware\HttpFullAuthentication([
        //     "path" =>"/login",
        //     "secure" => false,
        //     "authenticator" => new PdoAuthenticator([
        //         "pdo" => $this->pdo
        //     ])
        // ]));
    }
}
